import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { ShieldAlert } from "lucide-react";

export default function AdminGuard({ children }) {
  const [state, setState] = useState({ loading: true, isAdmin: false });

  useEffect(() => {
    base44.auth.isAuthenticated().then(async (authed) => {
      if (authed) {
        const user = await base44.auth.me();
        setState({ loading: false, isAdmin: user?.role === "admin" });
      } else {
        setState({ loading: false, isAdmin: false });
      }
    });
  }, []);

  if (state.loading) {
    return (
      <div className="flex items-center justify-center py-32">
        <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!state.isAdmin) {
    return (
      <div className="flex flex-col items-center justify-center py-32 text-center px-4">
        <ShieldAlert className="w-12 h-12 text-destructive mb-4" />
        <h2 className="font-display text-2xl font-bold mb-2">Access Restricted</h2>
        <p className="text-muted-foreground">This area is only available to team administrators.</p>
      </div>
    );
  }

  return children;
}