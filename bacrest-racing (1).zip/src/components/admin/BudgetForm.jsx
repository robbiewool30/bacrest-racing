import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { X } from "lucide-react";

const categories = ["Flights", "Entry Fees", "Accommodation", "Food", "Travel", "Training Fees", "Equipment", "Other"];

export default function BudgetForm({ item, onClose, onSaved }) {
  const [form, setForm] = useState(item || {
    category: "Flights", description: "", event_name: "",
    projected_amount: "", actual_amount: "", date: "", paid: false, notes: "",
  });
  const [saving, setSaving] = useState(false);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const handleSave = async () => {
    setSaving(true);
    const data = {
      ...form,
      projected_amount: form.projected_amount ? Number(form.projected_amount) : null,
      actual_amount: form.actual_amount ? Number(form.actual_amount) : null,
    };
    if (item?.id) {
      await base44.entities.BudgetItem.update(item.id, data);
    } else {
      await base44.entities.BudgetItem.create(data);
    }
    setSaving(false);
    onSaved();
  };

  return (
    <div className="bg-card border rounded-xl p-6 mb-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-lg">{item ? "Edit Expense" : "Add Expense"}</h3>
        <Button variant="ghost" size="icon" onClick={onClose}><X className="w-4 h-4" /></Button>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <div><Label>Category *</Label>
          <Select value={form.category} onValueChange={(v) => set("category", v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{categories.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div><Label>Description *</Label><Input value={form.description} onChange={(e) => set("description", e.target.value)} /></div>
        <div><Label>Event / Trip</Label><Input value={form.event_name} onChange={(e) => set("event_name", e.target.value)} /></div>
        <div><Label>Projected Amount (NZD)</Label><Input type="number" value={form.projected_amount} onChange={(e) => set("projected_amount", e.target.value)} /></div>
        <div><Label>Actual Amount (NZD)</Label><Input type="number" value={form.actual_amount} onChange={(e) => set("actual_amount", e.target.value)} /></div>
        <div><Label>Date</Label><Input type="date" value={form.date} onChange={(e) => set("date", e.target.value)} /></div>
        <div className="flex items-center gap-3 pt-6">
          <Switch checked={form.paid} onCheckedChange={(v) => set("paid", v)} />
          <Label>Paid</Label>
        </div>
      </div>
      <div className="mt-4"><Label>Notes</Label><Textarea value={form.notes} onChange={(e) => set("notes", e.target.value)} rows={2} /></div>
      <div className="mt-4 flex justify-end gap-3">
        <Button variant="outline" onClick={onClose}>Cancel</Button>
        <Button onClick={handleSave} disabled={saving || !form.description} className="bg-accent text-accent-foreground hover:opacity-90">
          {saving ? "Saving..." : "Save"}
        </Button>
      </div>
    </div>
  );
}