import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { X, Trophy } from "lucide-react";

const statuses = ["Planned", "Confirmed", "Completed", "Cancelled"];

function calcTotal(f) {
  const accom = (Number(f.accommodation_per_night) || 0) * (Number(f.accommodation_nights) || 0);
  const food = (Number(f.food_per_day_per_person) || 0) * (Number(f.event_days) || 0) * (Number(f.num_people) || 1);
  const entry = Number(f.entry_fee) || 0;
  const training = Number(f.training_fees) || 0;
  const equipment = Number(f.equipment_costs) || 0;
  const other = Number(f.other_costs) || 0;
  return accom + food + entry + training + equipment + other;
}

export default function RegattaForm({ regatta, tripId, trips = [], onClose, onSaved }) {
  const [form, setForm] = useState(regatta || {
    name: "", trip_id: tripId || "", location: "", country: "", start_date: "", end_date: "",
    num_people: "", people_names: "", entry_fee: "", accommodation_per_night: "",
    accommodation_nights: "", food_per_day_per_person: "", event_days: "",
    training_fees: "", equipment_costs: "", other_costs: "", notes: "", status: "Planned",
  });
  const [saving, setSaving] = useState(false);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const totalProjected = calcTotal(form);

  const handleSave = async () => {
    setSaving(true);
    const data = {
      ...form,
      trip_id: form.trip_id || null,
      num_people: form.num_people ? Number(form.num_people) : null,
      entry_fee: form.entry_fee ? Number(form.entry_fee) : null,
      accommodation_per_night: form.accommodation_per_night ? Number(form.accommodation_per_night) : null,
      accommodation_nights: form.accommodation_nights ? Number(form.accommodation_nights) : null,
      food_per_day_per_person: form.food_per_day_per_person ? Number(form.food_per_day_per_person) : null,
      event_days: form.event_days ? Number(form.event_days) : null,
      training_fees: form.training_fees ? Number(form.training_fees) : null,
      equipment_costs: form.equipment_costs ? Number(form.equipment_costs) : null,
      other_costs: form.other_costs ? Number(form.other_costs) : null,
    };
    if (regatta?.id) {
      await base44.entities.Regatta.update(regatta.id, data);
    } else {
      await base44.entities.Regatta.create(data);
    }
    setSaving(false);
    onSaved();
  };

  return (
    <div className="bg-card border rounded-xl p-6 mb-6 shadow-sm">
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-2">
          <Trophy className="w-5 h-5 text-accent" />
          <h3 className="font-semibold text-lg">{regatta ? "Edit Regatta" : "New Regatta"}</h3>
          {totalProjected > 0 && (
            <span className="ml-2 text-sm font-semibold text-accent bg-accent/10 px-2 py-0.5 rounded-full">
              Projected: ${totalProjected.toLocaleString()}
            </span>
          )}
        </div>
        <Button variant="ghost" size="icon" onClick={onClose}><X className="w-4 h-4" /></Button>
      </div>

      {/* Basic Info */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
        <div className="lg:col-span-2"><Label>Regatta Name *</Label><Input value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="e.g. Tasman Cup" /></div>
        <div><Label>Status</Label>
          <Select value={form.status} onValueChange={(v) => set("status", v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{statuses.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div><Label>Location</Label><Input value={form.location} onChange={(e) => set("location", e.target.value)} placeholder="Sydney" /></div>
        <div><Label>Country</Label><Input value={form.country} onChange={(e) => set("country", e.target.value)} placeholder="Australia" /></div>
        <div><Label>Trip (optional)</Label>
          <Select value={form.trip_id || "none"} onValueChange={(v) => set("trip_id", v === "none" ? "" : v)}>
            <SelectTrigger><SelectValue placeholder="Standalone regatta" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="none">No trip (standalone)</SelectItem>
              {trips.map((t) => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div><Label>Start Date</Label><Input type="date" value={form.start_date} onChange={(e) => set("start_date", e.target.value)} /></div>
        <div><Label>End Date</Label><Input type="date" value={form.end_date} onChange={(e) => set("end_date", e.target.value)} /></div>
      </div>

      {/* People */}
      <div className="grid sm:grid-cols-2 gap-4 mb-4 p-4 bg-muted/30 rounded-lg">
        <div>
          <Label>Number of People</Label>
          <Input type="number" value={form.num_people} onChange={(e) => set("num_people", e.target.value)} placeholder="2" />
          <p className="text-xs text-muted-foreground mt-1">Used to calculate food costs</p>
        </div>
        <div><Label>Who's attending</Label><Input value={form.people_names} onChange={(e) => set("people_names", e.target.value)} placeholder="e.g. Alex + Sam" /></div>
      </div>

      {/* Costs */}
      <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">Projected Costs</p>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
        <div><Label>Entry Fee (NZD)</Label><Input type="number" value={form.entry_fee} onChange={(e) => set("entry_fee", e.target.value)} /></div>
        <div><Label>Accommodation per Night (NZD)</Label><Input type="number" value={form.accommodation_per_night} onChange={(e) => set("accommodation_per_night", e.target.value)} /></div>
        <div><Label>Number of Nights</Label><Input type="number" value={form.accommodation_nights} onChange={(e) => set("accommodation_nights", e.target.value)} /></div>
        <div><Label>Food per Person per Day (NZD)</Label><Input type="number" value={form.food_per_day_per_person} onChange={(e) => set("food_per_day_per_person", e.target.value)} /></div>
        <div><Label>Event Days</Label><Input type="number" value={form.event_days} onChange={(e) => set("event_days", e.target.value)} /></div>
        <div><Label>Training Fees (NZD)</Label><Input type="number" value={form.training_fees} onChange={(e) => set("training_fees", e.target.value)} /></div>
        <div><Label>Equipment Costs (NZD)</Label><Input type="number" value={form.equipment_costs} onChange={(e) => set("equipment_costs", e.target.value)} /></div>
        <div><Label>Other Costs (NZD)</Label><Input type="number" value={form.other_costs} onChange={(e) => set("other_costs", e.target.value)} /></div>
      </div>

      {/* Running total */}
      {totalProjected > 0 && (
        <div className="mb-4 p-3 bg-accent/5 border border-accent/20 rounded-lg">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Entry: ${(Number(form.entry_fee)||0).toLocaleString()}</span>
            <span className="text-muted-foreground">Accommodation: ${((Number(form.accommodation_per_night)||0)*(Number(form.accommodation_nights)||0)).toLocaleString()}</span>
            <span className="text-muted-foreground">Food: ${((Number(form.food_per_day_per_person)||0)*(Number(form.event_days)||0)*(Number(form.num_people)||1)).toLocaleString()}</span>
            <span className="font-bold text-accent">Total: ${totalProjected.toLocaleString()}</span>
          </div>
        </div>
      )}

      <div className="mb-5"><Label>Notes</Label><Textarea value={form.notes} onChange={(e) => set("notes", e.target.value)} rows={2} /></div>

      <div className="flex justify-end gap-3">
        <Button variant="outline" onClick={onClose}>Cancel</Button>
        <Button onClick={handleSave} disabled={saving || !form.name} className="bg-accent text-accent-foreground hover:opacity-90">
          {saving ? "Saving..." : regatta ? "Update Regatta" : "Create Regatta"}
        </Button>
      </div>
    </div>
  );
}