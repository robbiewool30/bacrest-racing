import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { X } from "lucide-react";

const categories = ["Platinum", "Gold", "Silver", "Official Partner", "Preferred", "Other"];
const statuses = ["To Contact", "Contacted", "In Discussion", "Proposal Sent", "Accepted", "Declined", "Follow Up"];
const types = ["Cash", "In-Kind", "Both"];
const priorities = ["High", "Medium", "Low"];
const partnerRoles = ["Airline", "Accommodation", "Logistics / Freight", "Apparel", "Formalwear", "Camera", "GPS / Watch", "Sailing Analytics", "Nutrition", "Hydration", "Recovery", "Sun Protection", "Eyewear", "Communications", "Media / Audio", "Simulator / Hardware", "Other"];

export default function SponsorForm({ sponsor, onClose, onSaved }) {
  const [form, setForm] = useState(sponsor || {
    company_name: "", category: "Silver", status: "To Contact", contact_person: "", contact_email: "",
    amount_asked: "", amount_confirmed: "", in_kind_value: "", type: "Cash", notes: "",
    last_contact_date: "", ytp_conflict: false, priority: "Medium", partner_role: "",
  });
  const [saving, setSaving] = useState(false);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const handleSave = async () => {
    setSaving(true);
    const data = {
      ...form,
      amount_asked: form.amount_asked ? Number(form.amount_asked) : null,
      amount_confirmed: form.amount_confirmed ? Number(form.amount_confirmed) : null,
      in_kind_value: form.in_kind_value ? Number(form.in_kind_value) : null,
    };
    if (sponsor?.id) {
      await base44.entities.SponsorTracker.update(sponsor.id, data);
    } else {
      await base44.entities.SponsorTracker.create(data);
    }
    setSaving(false);
    onSaved();
  };

  return (
    <div className="bg-card border rounded-xl p-6 mb-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-lg">{sponsor ? "Edit Sponsor" : "Add Sponsor"}</h3>
        <Button variant="ghost" size="icon" onClick={onClose}><X className="w-4 h-4" /></Button>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <div><Label>Company Name *</Label><Input value={form.company_name} onChange={(e) => set("company_name", e.target.value)} /></div>
        <div><Label>Category</Label>
          <Select value={form.category} onValueChange={(v) => set("category", v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{categories.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div><Label>Status</Label>
          <Select value={form.status} onValueChange={(v) => set("status", v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{statuses.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        {form.category === "Official Partner" && (
          <div><Label>Partner Role *</Label>
            <Select value={form.partner_role || ""} onValueChange={(v) => set("partner_role", v)}>
              <SelectTrigger><SelectValue placeholder="What are they sponsoring?" /></SelectTrigger>
              <SelectContent>{partnerRoles.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
            </Select>
          </div>
        )}
        <div><Label>Contact Person</Label><Input value={form.contact_person} onChange={(e) => set("contact_person", e.target.value)} /></div>
        <div><Label>Contact Email</Label><Input type="email" value={form.contact_email} onChange={(e) => set("contact_email", e.target.value)} /></div>
        <div><Label>Type</Label>
          <Select value={form.type} onValueChange={(v) => set("type", v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{types.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div><Label>Amount Asked (NZD)</Label><Input type="number" value={form.amount_asked} onChange={(e) => set("amount_asked", e.target.value)} /></div>
        <div><Label>Amount Confirmed (NZD)</Label><Input type="number" value={form.amount_confirmed} onChange={(e) => set("amount_confirmed", e.target.value)} /></div>
        <div><Label>In-Kind Value (NZD)</Label><Input type="number" value={form.in_kind_value} onChange={(e) => set("in_kind_value", e.target.value)} /></div>
        <div><Label>Last Contact Date</Label><Input type="date" value={form.last_contact_date} onChange={(e) => set("last_contact_date", e.target.value)} /></div>
        <div><Label>Priority</Label>
          <Select value={form.priority} onValueChange={(v) => set("priority", v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{priorities.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div className="flex items-center gap-3 pt-6">
          <Switch checked={form.ytp_conflict} onCheckedChange={(v) => set("ytp_conflict", v)} />
          <Label>YTP Conflict</Label>
        </div>
      </div>
      <div className="mt-4"><Label>Notes</Label><Textarea value={form.notes} onChange={(e) => set("notes", e.target.value)} rows={3} /></div>
      <div className="mt-4 flex justify-end gap-3">
        <Button variant="outline" onClick={onClose}>Cancel</Button>
        <Button onClick={handleSave} disabled={saving || !form.company_name} className="bg-accent text-accent-foreground hover:opacity-90">
          {saving ? "Saving..." : "Save"}
        </Button>
      </div>
    </div>
  );
}