import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { X, Plus, Trash2, PlaneTakeoff } from "lucide-react";

function newLeg() {
  return { id: Date.now().toString(), from: "", to: "", date: "", num_people: "", people_names: "", cost_per_person: "", total_cost: "", actual_cost: "", notes: "" };
}

export default function TripForm({ trip, onClose, onSaved }) {
  const [form, setForm] = useState(trip || { name: "", description: "", start_date: "", end_date: "", notes: "", flight_legs: [] });
  const [saving, setSaving] = useState(false);

  const setField = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const addLeg = () => setForm((f) => ({ ...f, flight_legs: [...(f.flight_legs || []), newLeg()] }));

  const updateLeg = (i, key, val) => {
    const legs = [...(form.flight_legs || [])];
    legs[i] = { ...legs[i], [key]: val };
    // Auto-calc total
    if (key === "cost_per_person" || key === "num_people") {
      const pp = key === "cost_per_person" ? Number(val) : Number(legs[i].cost_per_person);
      const np = key === "num_people" ? Number(val) : Number(legs[i].num_people);
      if (pp && np) legs[i].total_cost = pp * np;
    }
    setForm((f) => ({ ...f, flight_legs: legs }));
  };

  const removeLeg = (i) => {
    const legs = [...(form.flight_legs || [])];
    legs.splice(i, 1);
    setForm((f) => ({ ...f, flight_legs: legs }));
  };

  const handleSave = async () => {
    setSaving(true);
    const data = {
      ...form,
      flight_legs: (form.flight_legs || []).map((leg) => ({
        ...leg,
        num_people: leg.num_people ? Number(leg.num_people) : null,
        cost_per_person: leg.cost_per_person ? Number(leg.cost_per_person) : null,
        total_cost: leg.total_cost ? Number(leg.total_cost) : null,
        actual_cost: leg.actual_cost ? Number(leg.actual_cost) : null,
      })),
    };
    if (trip?.id) {
      await base44.entities.Trip.update(trip.id, data);
    } else {
      await base44.entities.Trip.create(data);
    }
    setSaving(false);
    onSaved();
  };

  return (
    <div className="bg-card border rounded-xl p-6 mb-6 shadow-sm">
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-2">
          <PlaneTakeoff className="w-5 h-5 text-primary" />
          <h3 className="font-semibold text-lg">{trip ? "Edit Trip" : "New Trip"}</h3>
        </div>
        <Button variant="ghost" size="icon" onClick={onClose}><X className="w-4 h-4" /></Button>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-5">
        <div className="lg:col-span-2"><Label>Trip Name *</Label><Input value={form.name} onChange={(e) => setField("name", e.target.value)} placeholder="e.g. Sydney + Perth Trip" /></div>
        <div><Label>Start Date</Label><Input type="date" value={form.start_date} onChange={(e) => setField("start_date", e.target.value)} /></div>
        <div><Label>End Date</Label><Input type="date" value={form.end_date} onChange={(e) => setField("end_date", e.target.value)} /></div>
      </div>
      <div className="mb-5"><Label>Description</Label><Textarea value={form.description} onChange={(e) => setField("description", e.target.value)} rows={2} placeholder="Overview of this trip..." /></div>

      {/* Flight Legs */}
      <div className="mb-5">
        <div className="flex items-center justify-between mb-3">
          <Label className="text-sm font-semibold">Flight Legs</Label>
          <Button size="sm" variant="outline" onClick={addLeg}><Plus className="w-3.5 h-3.5 mr-1" /> Add Leg</Button>
        </div>
        <p className="text-xs text-muted-foreground mb-3">Add each flight separately — different legs can have different people. e.g. 5 people Auckland→Sydney, then 5 people Sydney→Perth, whilst 1 person Auckland→Perth direct.</p>

        {(form.flight_legs || []).length === 0 && (
          <div className="text-center py-6 bg-muted/30 rounded-lg text-sm text-muted-foreground">
            No flight legs yet. Click "Add Leg" to start.
          </div>
        )}

        <div className="space-y-3">
          {(form.flight_legs || []).map((leg, i) => (
            <div key={leg.id || i} className="bg-blue-50 border border-blue-100 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-semibold text-blue-700">Leg {i + 1}</span>
                <Button variant="ghost" size="icon" onClick={() => removeLeg(i)}><Trash2 className="w-3.5 h-3.5 text-destructive" /></Button>
              </div>
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
                <div><Label className="text-xs">From</Label><Input value={leg.from} onChange={(e) => updateLeg(i, "from", e.target.value)} placeholder="Auckland" /></div>
                <div><Label className="text-xs">To</Label><Input value={leg.to} onChange={(e) => updateLeg(i, "to", e.target.value)} placeholder="Sydney" /></div>
                <div><Label className="text-xs">Date</Label><Input type="date" value={leg.date} onChange={(e) => updateLeg(i, "date", e.target.value)} /></div>
                <div><Label className="text-xs">Who's on this leg</Label><Input value={leg.people_names} onChange={(e) => updateLeg(i, "people_names", e.target.value)} placeholder="e.g. Alex, Sam, 3 others" /></div>
                <div><Label className="text-xs">No. of People</Label><Input type="number" value={leg.num_people} onChange={(e) => updateLeg(i, "num_people", e.target.value)} /></div>
                <div><Label className="text-xs">Cost per Person (NZD)</Label><Input type="number" value={leg.cost_per_person} onChange={(e) => updateLeg(i, "cost_per_person", e.target.value)} /></div>
                <div><Label className="text-xs">Total Cost (NZD)</Label><Input type="number" value={leg.total_cost} onChange={(e) => updateLeg(i, "total_cost", e.target.value)} /></div>
                <div><Label className="text-xs">Actual Cost (NZD)</Label><Input type="number" value={leg.actual_cost} onChange={(e) => updateLeg(i, "actual_cost", e.target.value)} /></div>
              </div>
              <div className="mt-2"><Label className="text-xs">Notes</Label><Input value={leg.notes} onChange={(e) => updateLeg(i, "notes", e.target.value)} placeholder="e.g. direct flight, includes baggage" /></div>
            </div>
          ))}
        </div>
      </div>

      <div className="mb-5"><Label>Trip Notes</Label><Textarea value={form.notes} onChange={(e) => setField("notes", e.target.value)} rows={2} /></div>

      <div className="flex justify-end gap-3">
        <Button variant="outline" onClick={onClose}>Cancel</Button>
        <Button onClick={handleSave} disabled={saving || !form.name} className="bg-primary text-primary-foreground hover:opacity-90">
          {saving ? "Saving..." : trip ? "Update Trip" : "Create Trip"}
        </Button>
      </div>
    </div>
  );
}