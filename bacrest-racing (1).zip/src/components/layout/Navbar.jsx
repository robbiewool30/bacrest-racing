import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X } from "lucide-react";
import { base44 } from "@/api/base44Client";

const publicLinks = [
  { label: "Team", path: "/team" },
  { label: "Campaign", path: "/campaign" },
  { label: "News", path: "/news" },
  { label: "Results", path: "/results" },
  { label: "Media", path: "/media" },
  { label: "Partners", path: "/partners" },
  { label: "Sponsorship", path: "/sponsorship" },
  { label: "Contact", path: "/contact" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    base44.auth.isAuthenticated().then(async (authed) => {
      if (authed) {
        const user = await base44.auth.me();
        setIsAdmin(user?.role === "admin");
      }
    });
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const links = isAdmin
    ? [...publicLinks, { label: "Admin", path: "/admin" }]
    : publicLinks;

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      scrolled
        ? "bg-[hsl(220,15%,5%)]/95 backdrop-blur-md border-b border-white/5"
        : "bg-transparent"
    }`}>
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 group">
            <img src="https://media.base44.com/images/public/69fc1bba3da642f89dcfa939/e033d8cea_ChatGPTImageMay7202606_26_03PM.png" alt="Bacrest Racing" className="w-36 h-36 object-contain" />
            <span className="font-display font-700 text-base tracking-[0.15em] uppercase text-white/90 group-hover:text-white transition-colors">
              Bacrest Racing
            </span>
          </Link>

          {/* Desktop nav */}
          <div className="hidden lg:flex items-center gap-0">
            {links.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`px-4 py-2 text-xs font-600 tracking-[0.12em] uppercase transition-colors duration-200 ${
                  location.pathname === link.path
                    ? "text-crimson"
                    : "text-white/50 hover:text-white/90"
                }`}
              >
                {link.label}
              </Link>
            ))}
          </div>

          <button
            onClick={() => setOpen(!open)}
            className="lg:hidden text-white/60 hover:text-white transition-colors p-2"
          >
            {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="lg:hidden bg-[hsl(220,15%,5%)] border-t border-white/5 px-6 pb-6">
          {links.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              onClick={() => setOpen(false)}
              className={`block py-3 text-xs font-600 tracking-[0.12em] uppercase border-b border-white/5 transition-colors ${
                location.pathname === link.path
                  ? "text-crimson"
                  : "text-white/50 hover:text-white"
              }`}
            >
              {link.label}
            </Link>
          ))}
        </div>
      )}
    </nav>
  );
}