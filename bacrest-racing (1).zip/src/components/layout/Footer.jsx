import React from "react";
import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <footer className="bg-[hsl(220,15%,4%)] border-t border-white/5 mt-auto">
      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-3">
              <img src="https://media.base44.com/images/public/69fc1bba3da642f89dcfa939/e033d8cea_ChatGPTImageMay7202606_26_03PM.png" alt="Bacrest Racing" className="w-20 h-20 object-contain" />
              <span className="font-display font-700 text-sm tracking-[0.15em] uppercase text-white/80">
                Bacrest Racing
              </span>
            </div>
            <p className="text-xs text-white/30 tracking-wider uppercase">Match Racing · New Zealand · 2027</p>
          </div>

          {/* Links */}
          <div className="flex flex-wrap gap-x-8 gap-y-2">
            {[
              { label: "Team", path: "/team" },
              { label: "Campaign", path: "/campaign" },
              { label: "Results", path: "/results" },
              { label: "Partners", path: "/partners" },
              { label: "Sponsorship", path: "/sponsorship" },
              { label: "Contact", path: "/contact" },
            ].map((l) => (
              <Link
                key={l.path}
                to={l.path}
                className="text-xs text-white/30 hover:text-white/70 tracking-[0.1em] uppercase transition-colors"
              >
                {l.label}
              </Link>
            ))}
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p className="text-xs text-white/20 tracking-wide">&copy; {new Date().getFullYear()} Bacrest Racing. All rights reserved.</p>
          <div className="flex items-center gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-crimson" />
            <span className="text-xs text-white/20 tracking-wider uppercase">New Zealand</span>
          </div>
        </div>
      </div>
    </footer>
  );
}