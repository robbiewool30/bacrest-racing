import React from "react";

export default function PageHero({ title, subtitle, eyebrow }) {
  return (
    <section className="relative pt-32 pb-16 overflow-hidden carbon-bg grid-line-overlay">
      {/* Red accent line */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-crimson/60 to-transparent" />
      
      {/* Glow */}
      <div className="absolute top-16 left-1/2 -translate-x-1/2 w-96 h-32 bg-crimson/5 rounded-full blur-3xl pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-6">
        {eyebrow && (
          <p className="text-xs font-600 tracking-[0.2em] uppercase text-crimson mb-3">{eyebrow}</p>
        )}
        <h1 className="font-display text-5xl sm:text-7xl font-800 uppercase tracking-wide text-white leading-none">
          {title}
        </h1>
        {subtitle && (
          <p className="mt-4 text-sm text-white/40 max-w-lg tracking-wide leading-relaxed">{subtitle}</p>
        )}
        <div className="mt-6 w-12 h-px bg-crimson" />
      </div>
    </section>
  );
}