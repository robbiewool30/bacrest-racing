import React from "react";

export default function SectionHeader({ title, subtitle, light = false }) {
  return (
    <div className="text-center mb-10">
      <h2 className={`font-display text-3xl sm:text-4xl font-bold ${light ? "text-white" : "text-foreground"}`}>
        {title}
      </h2>
      {subtitle && (
        <p className={`mt-3 max-w-2xl mx-auto text-base ${light ? "text-white/70" : "text-muted-foreground"}`}>
          {subtitle}
        </p>
      )}
      <div className={`mt-4 mx-auto w-16 h-1 rounded-full ${light ? "bg-accent" : "bg-accent"}`} />
    </div>
  );
}