import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import PageHero from "@/components/shared/PageHero";
import { User, ChevronRight } from "lucide-react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";

export default function Team() {
  const { data: members = [] } = useQuery({
    queryKey: ["team-members"],
    queryFn: () => base44.entities.TeamMember.list("order"),
  });

  return (
    <div className="bg-background">
      <PageHero
        eyebrow="Bacrest Racing"
        title="The Crew"
        subtitle="The athletes and specialists behind the campaign."
      />

      <section className="py-20 max-w-7xl mx-auto px-6">
        {members.length === 0 ? (
          <p className="text-center text-white/30 tracking-wider uppercase text-xs">Crew profiles coming soon.</p>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-px bg-white/5">
            {members.map((m, i) => (
              <motion.div
                key={m.id}
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
              >
                <Link
                  to={`/sailor/${m.id}`}
                  className="block relative bg-background group overflow-hidden"
                >
                  {/* Photo */}
                  <div className="relative aspect-[3/4] overflow-hidden">
                    {m.photo_url ? (
                      <img
                        src={m.photo_url}
                        alt={m.name}
                        className="w-full h-full object-cover object-top grayscale group-hover:grayscale-0 group-hover:scale-105 transition-all duration-700"
                      />
                    ) : (
                      <div className="w-full h-full carbon-bg flex items-center justify-center">
                        <User className="w-16 h-16 text-white/10" />
                      </div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-background via-background/30 to-transparent" />
                    {/* Red accent on hover */}
                    <div className="absolute bottom-0 left-0 right-0 h-px bg-crimson scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left" />
                  </div>

                  {/* Info */}
                  <div className="p-6">
                    <p className="text-xs font-600 tracking-[0.2em] uppercase text-crimson mb-1">{m.role}</p>
                    <h3 className="font-display text-2xl font-700 uppercase tracking-wide text-white">{m.name}</h3>
                    {m.hometown && (
                      <p className="text-xs text-white/30 mt-1 tracking-wide">{m.hometown}</p>
                    )}
                    {m.bio && (
                      <p className="mt-3 text-xs text-white/40 leading-relaxed line-clamp-2">{m.bio}</p>
                    )}
                    <div className="mt-4 flex items-center gap-2 text-white/30 group-hover:text-white/70 transition-colors">
                      <span className="text-xs tracking-[0.15em] uppercase">Profile</span>
                      <ChevronRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        )}
      </section>

      {/* Philosophy */}
      <section className="relative border-t border-white/5 carbon-bg grid-line-overlay">
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-crimson/30 to-transparent" />
        <div className="max-w-4xl mx-auto px-6 py-20 text-center">
          <p className="text-xs font-600 tracking-[0.2em] uppercase text-crimson mb-4">Philosophy</p>
          <h3 className="font-display text-4xl sm:text-5xl font-800 uppercase tracking-wide text-white leading-none mb-6">
            One Boat.<br /><span className="text-white/30">One Objective.</span>
          </h3>
          <p className="text-sm text-white/40 max-w-2xl mx-auto leading-relaxed tracking-wide">
            Match racing is the purest form of sailing competition — one crew against another, where preparation, trust, and split-second execution determine the outcome. We train relentlessly, race with controlled aggression, and represent New Zealand with professional standards at every event.
          </p>
        </div>
      </section>
    </div>
  );
}