import React from "react";
import { Link } from "react-router-dom";
import { ArrowRight, ChevronRight } from "lucide-react";
import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

const DEFAULT_PILLARS = [
  { number: "01", title: "Precision Racing", desc: "Match racing at the highest level demands split-second decision-making and flawless boat-handling under extreme pressure." },
  { number: "02", title: "2027 Campaign", desc: "Four international World Tour events. November 2026 through October 2027. New Zealand to the world." },
  { number: "03", title: "Systems Approach", desc: "Every element of the campaign — technical, physical, tactical — engineered and optimised as an integrated system." },
];

function useHomeContent(sectionKey) {
  const { data = [] } = useQuery({
    queryKey: ["site-content", `home_${sectionKey}`],
    queryFn: () => base44.entities.SiteContent.filter({ key: `home_${sectionKey}` }),
  });
  return data[0] || {};
}

export default function Home() {
  const hero = useHomeContent("hero");
  const brief = useHomeContent("campaign_brief");
  const pillarsContent = useHomeContent("pillars");
  const cta = useHomeContent("partner_cta");

  const pillars = pillarsContent.extra?.pillars || DEFAULT_PILLARS;

  const heroTitle = hero.title || "Precision\nUnder\nPressure";
  const heroSubtitle = hero.subtitle || "New Zealand · Match Racing · 2027";
  const heroBody = hero.body || "A professional New Zealand match racing campaign — built for the world stage.";
  const heroImage = hero.image_url || "https://media.base44.com/images/public/69fc1bba3da642f89dcfa939/3040c3b96_FB_IMG_1772314103884.jpg";

  const briefTitle = brief.title || "World Tour.";
  const briefSubtitle = brief.subtitle || "World Class.";
  const briefBody = brief.body || "Bacrest Racing is a professional New Zealand match racing campaign competing at ISAF World Tour level events. We operate with the same systems and standards as established international programmes.";
  const briefImage = brief.image_url || "https://media.base44.com/images/public/69fc1bba3da642f89dcfa939/fc6312d7a_20251115_NZ-Match-Racing-Champs_SH_Live-Sail-Die-105.jpg";

  const ctaTitle = cta.title || "Invest in\nPerformance";
  const ctaBody = cta.body || "Align your brand with precision, ambition, and the pursuit of excellence on the international stage.";

  return (
    <div className="bg-background min-h-screen">
      {/* ── HERO ──────────────────────────────────────────────────────── */}
      <section className="relative h-screen min-h-[700px] flex items-end overflow-hidden">
        {/* Background image */}
        <div className="absolute inset-0">
          <img
            src={heroImage}
            alt="Match racing"
            className="w-full h-full object-cover object-center"
          />
          {/* Cinematic overlays */}
          <div className="absolute inset-0 bg-gradient-to-t from-[hsl(220,15%,4%)] via-[hsl(220,15%,4%)]/60 to-[hsl(220,15%,4%)]/20" />
          <div className="absolute inset-0 bg-gradient-to-r from-[hsl(220,15%,4%)]/70 via-transparent to-transparent" />
        </div>

        {/* Top accent line */}
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-crimson/80 via-crimson/20 to-transparent" />

        {/* Content */}
        <div className="relative max-w-7xl mx-auto px-6 pb-20 w-full">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <p className="text-xs font-600 tracking-[0.25em] uppercase text-crimson mb-4">
              {heroSubtitle}
            </p>
            <h1 className="font-display text-[clamp(3rem,10vw,8rem)] font-900 uppercase leading-none text-white tracking-tight whitespace-pre-line">
              {heroTitle}
            </h1>
            <div className="mt-8 w-12 h-px bg-crimson mb-8" />
            <p className="text-sm text-white/40 max-w-sm leading-relaxed mb-10 tracking-wide">
              {heroBody}
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                to="/campaign"
                className="inline-flex items-center gap-3 bg-crimson text-white px-8 py-3 text-xs font-700 tracking-[0.15em] uppercase hover:bg-crimson/90 transition-colors group"
              >
                The Campaign
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link
                to="/sponsorship"
                className="inline-flex items-center gap-3 border border-white/15 text-white/60 px-8 py-3 text-xs font-700 tracking-[0.15em] uppercase hover:border-white/30 hover:text-white/90 transition-colors"
              >
                Partner With Us
              </Link>
            </div>
          </motion.div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 right-8 flex items-center gap-2 text-white/20">
          <div className="w-px h-8 bg-white/20" />
          <span className="text-xs tracking-[0.2em] uppercase rotate-90 origin-left translate-x-6">Scroll</span>
        </div>
      </section>

      {/* ── PILLARS ───────────────────────────────────────────────────── */}
      <section className="relative border-t border-white/5">
        <div className="max-w-7xl mx-auto px-6 py-24">
          <div className="grid md:grid-cols-3 gap-0 divide-y md:divide-y-0 md:divide-x divide-white/5">
            {pillars.map((p, i) => (
              <motion.div
                key={p.number}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.12, duration: 0.6 }}
                className="px-8 py-10 first:pl-0 last:pr-0"
              >
                <span className="text-xs font-700 text-crimson tracking-[0.2em] mb-4 block">{p.number}</span>
                <h3 className="font-display text-2xl font-700 uppercase tracking-wide text-white mb-3">{p.title}</h3>
                <p className="text-xs text-white/40 leading-relaxed tracking-wide">{p.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CAMPAIGN BRIEF ────────────────────────────────────────────── */}
      <section className="relative carbon-bg grid-line-overlay border-t border-white/5">
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-crimson/30 to-transparent" />
        <div className="max-w-7xl mx-auto px-6 py-24">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <p className="text-xs font-600 tracking-[0.2em] uppercase text-crimson mb-4">Campaign Brief</p>
              <h2 className="font-display text-5xl sm:text-6xl font-800 uppercase tracking-wide text-white leading-none mb-6">
                {briefTitle}<br />
                <span className="text-white/30">{briefSubtitle}</span>
              </h2>
              <p className="text-sm text-white/40 leading-relaxed tracking-wide mb-8 max-w-md">
                {briefBody}
              </p>
              <Link
                to="/campaign"
                className="inline-flex items-center gap-2 text-xs font-700 tracking-[0.15em] uppercase text-white/60 hover:text-white transition-colors group"
              >
                Campaign Details
                <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>
            <div className="relative">
              <img
                src={briefImage}
                alt="Racing"
                className="w-full aspect-[4/3] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/60 via-transparent to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 h-px bg-crimson/30" />
            </div>
          </div>
        </div>
      </section>

      {/* ── PARTNER CTA ───────────────────────────────────────────────── */}
      <section className="border-t border-white/5 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-crimson/5 via-transparent to-transparent pointer-events-none" />
        <div className="max-w-7xl mx-auto px-6 py-24 text-center">
          <p className="text-xs font-600 tracking-[0.2em] uppercase text-crimson mb-4">Partnership</p>
          <h2 className="font-display text-5xl sm:text-6xl font-800 uppercase tracking-wide text-white leading-none mb-4 whitespace-pre-line">
            {ctaTitle}
          </h2>
          <p className="text-sm text-white/30 max-w-md mx-auto leading-relaxed tracking-wide mb-10">
            {ctaBody}
          </p>
          <Link
            to="/sponsorship"
            className="inline-flex items-center gap-3 bg-crimson text-white px-10 py-4 text-xs font-700 tracking-[0.15em] uppercase hover:bg-crimson/90 transition-colors group"
          >
            Explore Partnership Tiers
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
      </section>
    </div>
  );
}