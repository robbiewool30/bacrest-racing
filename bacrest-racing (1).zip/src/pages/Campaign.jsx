import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import PageHero from "@/components/shared/PageHero";
import { CheckCircle2, Clock, Target, Calendar } from "lucide-react";
import { motion } from "framer-motion";
import { format } from "date-fns";

const statusConfig = {
  Planned: { icon: Clock, color: "text-white/30", bar: "bg-white/10" },
  "In Progress": { icon: Target, color: "text-crimson", bar: "bg-crimson" },
  Achieved: { icon: CheckCircle2, color: "text-emerald-500", bar: "bg-emerald-500" },
};

const defaults = {
  eyebrow: "2027 Season",
  title: "The Campaign",
  subtitle: "A four-event international programme. Built to compete. Built to win.",
  stat1_value: "4", stat1_label: "Events",
  stat2_value: "2026–27", stat2_label: "Season",
  stat3_value: "World Tour", stat3_label: "Circuit",
  stat4_value: "New Zealand", stat4_label: "Base",
  short_term_label: "Immediate Objectives",
  long_term_label: "Long-Term Vision",
};

export default function Campaign() {
  const { data: goals = [] } = useQuery({
    queryKey: ["campaign-goals"],
    queryFn: () => base44.entities.CampaignGoal.list("order"),
  });

  const { data: contentList = [] } = useQuery({
    queryKey: ["campaign-content"],
    queryFn: () => base44.entities.SiteContent.filter({ key: "campaign_page" }),
  });

  const content = { ...defaults, ...(contentList[0]?.extra || {}) };

  const shortTerm = goals.filter((g) => g.timeframe === "Short Term");
  const longTerm = goals.filter((g) => g.timeframe === "Long Term");

  const stats = [1,2,3,4].map((n) => ({ value: content[`stat${n}_value`], label: content[`stat${n}_label`] }));

  const renderGoals = (list) =>
    list.length === 0 ? (
      <p className="text-white/20 text-xs tracking-wider uppercase">Objectives loading.</p>
    ) : (
      <div className="space-y-px">
        {list.map((g, i) => {
          const cfg = statusConfig[g.status] || statusConfig.Planned;
          const Icon = cfg.icon;
          return (
            <motion.div
              key={g.id}
              initial={{ opacity: 0, x: -10 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              className="relative bg-card border border-white/5 p-6 group hover:border-white/10 transition-colors"
            >
              <div className={`absolute left-0 top-0 bottom-0 w-0.5 ${cfg.bar}`} />
              <div className="flex items-start gap-4">
                <Icon className={`w-4 h-4 mt-0.5 flex-shrink-0 ${cfg.color}`} />
                <div className="flex-1">
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-1">
                    <h4 className="font-display text-base font-600 uppercase tracking-wide text-white/90">{g.title}</h4>
                    {g.target_date && (
                      <span className="text-xs text-white/25 flex items-center gap-1 tracking-wide">
                        <Calendar className="w-3 h-3" />
                        {format(new Date(g.target_date), "MMM yyyy")}
                      </span>
                    )}
                  </div>
                  {g.description && (
                    <p className="text-xs text-white/35 leading-relaxed tracking-wide">{g.description}</p>
                  )}
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    );

  return (
    <div className="bg-background">
      <PageHero
        eyebrow={content.eyebrow}
        title={content.title}
        subtitle={content.subtitle}
      />

      {/* Campaign overview strip */}
      <section className="border-y border-white/5 bg-card">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 divide-x divide-white/5">
            {stats.map((s) => (
              <div key={s.label} className="px-8 py-6 text-center">
                <p className="font-display text-3xl font-800 text-white uppercase">{s.value}</p>
                <p className="text-xs text-white/25 tracking-[0.15em] uppercase mt-1">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 max-w-4xl mx-auto px-6 space-y-16">
        <div>
          <div className="flex items-center gap-4 mb-8">
            <div className="w-2 h-2 bg-crimson" />
            <p className="text-xs font-700 tracking-[0.2em] uppercase text-white/50">{content.short_term_label}</p>
            <div className="flex-1 h-px bg-white/5" />
          </div>
          {renderGoals(shortTerm)}
        </div>

        <div>
          <div className="flex items-center gap-4 mb-8">
            <div className="w-2 h-2 bg-white/20" />
            <p className="text-xs font-700 tracking-[0.2em] uppercase text-white/50">{content.long_term_label}</p>
            <div className="flex-1 h-px bg-white/5" />
          </div>
          {renderGoals(longTerm)}
        </div>
      </section>
    </div>
  );
}