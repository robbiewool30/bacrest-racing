import React from "react";
import { Link } from "react-router-dom";
import PageHero from "@/components/shared/PageHero";
import { ArrowRight, Globe, Eye, Heart, Megaphone, Users, Trophy } from "lucide-react";
import { motion } from "framer-motion";

const reasons = [
  { icon: Globe, label: "International Reach", desc: "Your brand travels to World Tour events across the globe — exposure in premium sailing markets." },
  { icon: Eye, label: "Targeted Audience", desc: "Match racing attracts high-net-worth individuals, corporate decision-makers, and sailing media." },
  { icon: Heart, label: "Authentic Story", desc: "A Kiwi campaign competing on the world stage — compelling narrative content that resonates." },
  { icon: Megaphone, label: "Digital Coverage", desc: "Social media, video production, and editorial across all campaign channels and events." },
  { icon: Users, label: "Corporate Access", desc: "Exclusive regatta hospitality — experiences money cannot normally buy." },
  { icon: Trophy, label: "Winning Culture", desc: "Align your brand with precision, performance, and New Zealand competitive excellence." },
];

const tiers = [
  {
    name: "Platinum",
    sub: "Title Sponsor",
    range: "$30k – $50k+",
    desc: "Naming rights. Primary brand placement across all campaign assets. Identity-level partnership.",
    highlight: true,
  },
  {
    name: "Gold",
    sub: "Major Sponsor",
    range: "$10k – $20k",
    desc: "Major visibility, co-branded content, regatta presence and media association.",
    highlight: false,
  },
  {
    name: "Silver",
    sub: "Supporting Sponsor",
    range: "$1k – $5k",
    desc: "Logo placement, social mentions, and relationship-led partnership opportunities.",
    highlight: false,
  },
  {
    name: "Official Partner",
    sub: "In-Kind",
    range: "Product / Service",
    desc: "Strategic product and service partnerships that reduce campaign costs and elevate our operation.",
    highlight: false,
  },
];

export default function Sponsorship() {
  return (
    <div className="bg-background">
      <PageHero
        eyebrow="Opportunity"
        title="Partner With Us"
        subtitle="Invest in a professional match racing campaign representing New Zealand on the world stage."
      />

      {/* Why */}
      <section className="py-20 max-w-7xl mx-auto px-6">
        <div className="flex items-center gap-4 mb-12">
          <div className="w-2 h-2 bg-crimson" />
          <p className="text-xs font-700 tracking-[0.2em] uppercase text-white/50">Value Proposition</p>
          <div className="flex-1 h-px bg-white/5" />
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-px bg-white/5">
          {reasons.map((r, i) => (
            <motion.div
              key={r.label}
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.06 }}
              className="bg-background p-8 group"
            >
              <r.icon className="w-5 h-5 text-crimson mb-5" />
              <h4 className="font-display text-base font-700 uppercase tracking-wide text-white/90 mb-2">{r.label}</h4>
              <p className="text-xs text-white/35 leading-relaxed tracking-wide">{r.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Tiers */}
      <section className="border-t border-white/5 carbon-bg grid-line-overlay py-20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex items-center gap-4 mb-12">
            <div className="w-2 h-2 bg-crimson" />
            <p className="text-xs font-700 tracking-[0.2em] uppercase text-white/50">Sponsorship Tiers</p>
            <div className="flex-1 h-px bg-white/5" />
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-px bg-white/5">
            {tiers.map((t, i) => (
              <motion.div
                key={t.name}
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
                className={`relative p-8 ${t.highlight ? "bg-crimson/10" : "bg-background"}`}
              >
                {t.highlight && (
                  <div className="absolute top-0 left-0 right-0 h-px bg-crimson" />
                )}
                <p className="text-xs font-600 tracking-[0.2em] uppercase text-crimson mb-1">{t.name}</p>
                <p className="text-xs text-white/30 tracking-wide mb-5">{t.sub}</p>
                <p className="font-display text-2xl font-800 uppercase text-white mb-4">{t.range}</p>
                <div className="w-6 h-px bg-white/15 mb-4" />
                <p className="text-xs text-white/40 leading-relaxed tracking-wide">{t.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="border-t border-white/5 py-20">
        <div className="max-w-3xl mx-auto px-6 text-center">
          <p className="text-xs font-600 tracking-[0.2em] uppercase text-crimson mb-4">Next Step</p>
          <h3 className="font-display text-5xl font-800 uppercase tracking-wide text-white mb-4">Ready to Talk?</h3>
          <p className="text-sm text-white/30 mb-10 leading-relaxed tracking-wide max-w-md mx-auto">
            Every partnership starts with a conversation. We're direct, professional, and committed to making it work for you.
          </p>
          <Link
            to="/contact"
            className="inline-flex items-center gap-3 bg-crimson text-white px-10 py-4 text-xs font-700 tracking-[0.15em] uppercase hover:bg-crimson/90 transition-colors group"
          >
            Get in Touch
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
      </section>
    </div>
  );
}