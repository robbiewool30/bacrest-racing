import React, { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { User, ArrowLeft, MapPin, Flag, Trophy, Anchor, Instagram, X } from "lucide-react";
import { motion } from "framer-motion";

export default function SailorProfile() {
  const { id } = useParams();

  const { data: members = [], isLoading } = useQuery({
    queryKey: ["team-members"],
    queryFn: () => base44.entities.TeamMember.list("order"),
  });

  const member = members.find((m) => m.id === id);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <div className="w-6 h-6 border-2 border-white/10 border-t-crimson rounded-full animate-spin" />
      </div>
    );
  }

  if (!member) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center text-center px-6">
        <div>
          <p className="text-xs text-white/20 tracking-[0.2em] uppercase mb-4">Profile not found</p>
          <Link to="/team" className="text-xs text-crimson tracking-[0.15em] uppercase hover:text-crimson/70 transition-colors">
            ← Return to Team
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Back nav */}
      <div className="fixed top-16 left-0 right-0 z-40 border-b border-white/5 bg-background/90 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-6 h-10 flex items-center">
          <Link
            to="/team"
            className="inline-flex items-center gap-2 text-xs text-white/30 hover:text-white/70 tracking-[0.15em] uppercase transition-colors group"
          >
            <ArrowLeft className="w-3 h-3 group-hover:-translate-x-0.5 transition-transform" />
            Team
          </Link>
        </div>
      </div>

      <div className="pt-28 pb-24 max-w-6xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          {/* Hero layout */}
          <div className="grid lg:grid-cols-[400px_1fr] gap-16 items-start">
            {/* Photo */}
            <div className="relative">
              <div className="aspect-[3/4] overflow-hidden">
                {member.photo_url ? (
                  <img
                    src={member.photo_url}
                    alt={member.name}
                    className="w-full h-full object-cover object-top"
                  />
                ) : (
                  <div className="w-full h-full carbon-bg flex items-center justify-center">
                    <User className="w-20 h-20 text-white/10" />
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-transparent to-transparent" />
              </div>
              <div className="absolute bottom-0 left-0 right-0 h-px bg-crimson" />
              {member.instagram_url && (
                <a
                  href={member.instagram_url}
                  target="_blank"
                  rel="noreferrer"
                  className="absolute top-4 right-4 w-8 h-8 bg-background/80 backdrop-blur-sm flex items-center justify-center border border-white/10 text-white/40 hover:text-white transition-colors"
                >
                  <Instagram className="w-4 h-4" />
                </a>
              )}
            </div>

            {/* Info */}
            <div className="pt-4">
              <p className="text-xs font-600 tracking-[0.2em] uppercase text-crimson mb-2">{member.role}</p>
              <h1 className="font-display text-6xl sm:text-7xl font-900 uppercase leading-none text-white tracking-tight mb-6">
                {member.name}
              </h1>
              <div className="w-12 h-px bg-crimson mb-8" />

              {/* Meta */}
              <div className="flex flex-wrap gap-6 mb-8">
                {member.hometown && (
                  <div className="flex items-center gap-2 text-xs text-white/35 tracking-wide">
                    <MapPin className="w-3.5 h-3.5 text-crimson/60" />
                    {member.hometown}
                  </div>
                )}
                {member.nationality && (
                  <div className="flex items-center gap-2 text-xs text-white/35 tracking-wide">
                    <Flag className="w-3.5 h-3.5 text-crimson/60" />
                    {member.nationality}
                  </div>
                )}
              </div>

              {member.bio && (
                <p className="text-sm text-white/50 leading-relaxed tracking-wide max-w-xl mb-10">{member.bio}</p>
              )}

              {/* Detail blocks */}
              <div className="space-y-8">
                {member.sailing_experience && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.15 }}
                  >
                    <div className="flex items-center gap-3 mb-3">
                      <Anchor className="w-3.5 h-3.5 text-crimson" />
                      <p className="text-xs font-700 tracking-[0.15em] uppercase text-white/30">Sailing Background</p>
                    </div>
                    <p className="text-xs text-white/45 leading-relaxed tracking-wide whitespace-pre-line border-l border-white/10 pl-4">{member.sailing_experience}</p>
                  </motion.div>
                )}

                {member.notable_results && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.2 }}
                  >
                    <div className="flex items-center gap-3 mb-3">
                      <Trophy className="w-3.5 h-3.5 text-crimson" />
                      <p className="text-xs font-700 tracking-[0.15em] uppercase text-white/30">Notable Results</p>
                    </div>
                    <p className="text-xs text-white/45 leading-relaxed tracking-wide whitespace-pre-line border-l border-white/10 pl-4">{member.notable_results}</p>
                  </motion.div>
                )}
              </div>
            </div>
          </div>
          {/* Gallery */}
          {member.gallery_photos && member.gallery_photos.filter(Boolean).length > 0 && (
            <GallerySection photos={member.gallery_photos.filter(Boolean)} />
          )}
        </motion.div>
      </div>
    </div>
  );
}

function GallerySection({ photos }) {
  const [lightbox, setLightbox] = useState(null);

  return (
    <div className="mt-20">
      <div className="flex items-center gap-4 mb-8">
        <div className="w-2 h-2 bg-crimson" />
        <p className="text-xs font-700 tracking-[0.2em] uppercase text-white/40">Gallery</p>
        <div className="flex-1 h-px bg-white/5" />
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-px bg-white/5">
        {photos.map((url, i) => (
          <motion.button
            key={i}
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.05 }}
            onClick={() => setLightbox(url)}
            className="relative aspect-square overflow-hidden group bg-background"
          >
            <img
              src={url}
              alt={`Gallery ${i + 1}`}
              className="w-full h-full object-cover group-hover:scale-105 transition-all duration-500"
            />
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors" />
          </motion.button>
        ))}
      </div>

      {/* Lightbox */}
      {lightbox && (
        <div
          className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4"
          onClick={() => setLightbox(null)}
        >
          <button
            className="absolute top-6 right-6 text-white/50 hover:text-white transition-colors"
            onClick={() => setLightbox(null)}
          >
            <X className="w-6 h-6" />
          </button>
          <img
            src={lightbox}
            alt="Gallery"
            className="max-w-full max-h-[90vh] object-contain"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </div>
  );
}