import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import PageHero from "@/components/shared/PageHero";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Play, X, ChevronDown, ChevronUp } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

function MediaGrid({ items, onOpen }) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
      {items.map((m) => (
        <motion.div
          key={m.id}
          layout
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="relative aspect-video bg-muted rounded-lg overflow-hidden cursor-pointer group"
          onClick={() => onOpen(m)}
        >
          <img
            src={m.type === "video" ? (m.thumbnail_url || m.url) : m.url}
            alt={m.title}
            className="w-full h-full object-cover transition-transform group-hover:scale-105"
          />
          {m.type === "video" && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/30">
              <Play className="w-10 h-10 text-white" fill="white" />
            </div>
          )}
          {m.title && (
            <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/60 p-3">
              <p className="text-white text-sm font-medium truncate">{m.title}</p>
            </div>
          )}
        </motion.div>
      ))}
    </div>
  );
}

function AlbumSection({ album, items, onOpen, sectionRef }) {
  const [open, setOpen] = useState(true);
  const cover = items.find((m) => m.type === "image") || items[0];

  return (
    <div className="mb-12" ref={sectionRef}>
      <button
        className="w-full flex items-center justify-between gap-4 mb-4 group"
        onClick={() => setOpen((o) => !o)}
      >
        <div className="flex items-center gap-4">
          {cover && (
            <img src={cover.type === "video" ? (cover.thumbnail_url || cover.url) : cover.url} alt={album} className="w-12 h-8 object-cover rounded" />
          )}
          <div className="text-left">
            <h2 className="font-display text-xl font-700 uppercase tracking-wide text-white group-hover:text-crimson transition-colors">{album}</h2>
            <p className="text-xs text-white/30 mt-0.5">{items.length} item{items.length !== 1 ? "s" : ""}</p>
          </div>
        </div>
        {open ? <ChevronUp className="w-4 h-4 text-white/30 flex-shrink-0" /> : <ChevronDown className="w-4 h-4 text-white/30 flex-shrink-0" />}
      </button>
      <div className="w-full h-px bg-white/5 mb-4" />
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <MediaGrid items={items} onOpen={onOpen} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

const ORDER_KEY = "bacrest_album_order";
function loadAlbumOrder() {
  try { return JSON.parse(localStorage.getItem(ORDER_KEY) || "[]"); } catch { return []; }
}
function mergeOrder(saved, actual) {
  const existing = saved.filter((a) => actual.includes(a));
  const newOnes = actual.filter((a) => !existing.includes(a));
  return [...existing, ...newOnes];
}

export default function Media() {
  const [filter, setFilter] = useState("all");
  const [lightbox, setLightbox] = useState(null);
  const albumRefs = useRef({});

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const targetAlbum = params.get("album");
    if (targetAlbum) {
      // Wait for content to render then scroll
      setTimeout(() => {
        const el = albumRefs.current[targetAlbum];
        if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
      }, 400);
    }
  }, []);

  const { data: items = [] } = useQuery({
    queryKey: ["media"],
    queryFn: () => base44.entities.MediaItem.list("order"),
  });

  const filtered = filter === "all" ? items : items.filter((m) => m.type === filter);

  // Group by album; items with no album go into an "Ungrouped" bucket rendered at the end
  const albumMap = {};
  const ungrouped = [];
  for (const m of filtered) {
    if (m.album && m.album.trim()) {
      if (!albumMap[m.album]) albumMap[m.album] = [];
      albumMap[m.album].push(m);
    } else {
      ungrouped.push(m);
    }
  }

  // Respect album order saved by admin
  let savedOrder = [];
  try { savedOrder = JSON.parse(localStorage.getItem("bacrest_album_order") || "[]"); } catch { savedOrder = []; }
  const actualNames = Object.keys(albumMap);
  const orderedNames = [...savedOrder.filter((a) => actualNames.includes(a)), ...actualNames.filter((a) => !savedOrder.includes(a))];
  const albums = orderedNames.map((name) => [name, albumMap[name]]); // [[name, items], ...]

  return (
    <div>
      <PageHero title="Media" subtitle="Photos and videos from our campaign." />

      <section className="py-16 max-w-6xl mx-auto px-4 sm:px-6">
        <div className="flex justify-center mb-10">
          <Tabs value={filter} onValueChange={setFilter}>
            <TabsList>
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="image">Photos</TabsTrigger>
              <TabsTrigger value="video">Videos</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        {filtered.length === 0 ? (
          <p className="text-center text-muted-foreground">Media coming soon.</p>
        ) : (
          <>
            {albums.map(([album, albumItems]) => (
              <AlbumSection key={album} album={album} items={albumItems} onOpen={setLightbox} sectionRef={(el) => { albumRefs.current[album] = el; }} />
            ))}
            {ungrouped.length > 0 && (
              albums.length > 0 ? (
                <AlbumSection album="Other" items={ungrouped} onOpen={setLightbox} />
              ) : (
                <MediaGrid items={ungrouped} onOpen={setLightbox} />
              )
            )}
          </>
        )}
      </section>

      {/* Lightbox */}
      <AnimatePresence>
        {lightbox && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4"
            onClick={() => setLightbox(null)}
          >
            <button className="absolute top-4 right-4 text-white" onClick={() => setLightbox(null)}>
              <X className="w-6 h-6" />
            </button>
            {lightbox.type === "image" ? (
              <img src={lightbox.url} alt={lightbox.title} className="max-w-full max-h-[85vh] rounded-lg" />
            ) : (
              <div className="w-full max-w-3xl aspect-video" onClick={(e) => e.stopPropagation()}>
                <iframe src={lightbox.url} className="w-full h-full rounded-lg" allowFullScreen />
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}