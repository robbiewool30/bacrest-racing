import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import AdminGuard from "@/components/admin/AdminGuard";
import TripForm from "@/components/admin/TripForm";
import RegattaForm from "@/components/admin/RegattaForm";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Pencil, Trash2, ArrowLeft, ChevronDown, ChevronRight, PlaneTakeoff, Trophy, DollarSign } from "lucide-react";
import { Link } from "react-router-dom";
import { format } from "date-fns";

function calcRegattaTotal(r) {
  const accom = (r.accommodation_per_night || 0) * (r.accommodation_nights || 0);
  const food = (r.food_per_day_per_person || 0) * (r.event_days || 0) * (r.num_people || 1);
  const entry = r.entry_fee || 0;
  const training = r.training_fees || 0;
  const equipment = r.equipment_costs || 0;
  const other = r.other_costs || 0;
  return accom + food + entry + training + equipment + other;
}

function calcTripFlightsTotal(trip) {
  return (trip.flight_legs || []).reduce((sum, leg) => sum + (leg.total_cost || 0), 0);
}

export default function BudgetTracker() {
  const [showTripForm, setShowTripForm] = useState(false);
  const [editingTrip, setEditingTrip] = useState(null);
  const [showRegattaForm, setShowRegattaForm] = useState(false);
  const [editingRegatta, setEditingRegatta] = useState(null);
  const [regattaTripId, setRegattaTripId] = useState(null);
  const [expandedTrips, setExpandedTrips] = useState({});
  const [expandedStandalones, setExpandedStandalones] = useState(true);
  const qc = useQueryClient();

  const { data: trips = [] } = useQuery({
    queryKey: ["trips"],
    queryFn: () => base44.entities.Trip.list("start_date"),
  });

  const { data: regattas = [] } = useQuery({
    queryKey: ["regattas"],
    queryFn: () => base44.entities.Regatta.list("start_date"),
  });

  const { data: sponsors = [] } = useQuery({
    queryKey: ["sponsor-income"],
    queryFn: () => base44.entities.SponsorTracker.list(),
  });

  const deleteTripMut = useMutation({
    mutationFn: (id) => base44.entities.Trip.delete(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["trips"] }),
  });

  const deleteRegattaMut = useMutation({
    mutationFn: (id) => base44.entities.Regatta.delete(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["regattas"] }),
  });

  const confirmedIncome = sponsors.reduce((a, s) => a + (s.amount_confirmed || 0), 0);
  const inKindIncome = sponsors.reduce((a, s) => a + (s.in_kind_value || 0), 0);

  const totalRegattaCosts = regattas.reduce((sum, r) => sum + calcRegattaTotal(r), 0);
  const totalFlightCosts = trips.reduce((sum, t) => sum + calcTripFlightsTotal(t), 0);
  const totalProjected = totalRegattaCosts + totalFlightCosts;
  const balance = confirmedIncome - totalProjected;

  const tripRegattas = (tripId) => regattas.filter((r) => r.trip_id === tripId);
  const standaloneRegattas = regattas.filter((r) => !r.trip_id);

  const toggleTrip = (id) => setExpandedTrips((prev) => ({ ...prev, [id]: !prev[id] }));

  const openAddRegatta = (tripId = null) => {
    setEditingRegatta(null);
    setRegattaTripId(tripId);
    setShowRegattaForm(true);
  };

  const openEditRegatta = (r) => {
    setEditingRegatta(r);
    setRegattaTripId(r.trip_id || null);
    setShowRegattaForm(true);
  };

  return (
    <AdminGuard>
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
        <div className="flex items-center gap-3 mb-6">
          <Link to="/admin" className="text-muted-foreground hover:text-foreground"><ArrowLeft className="w-5 h-5" /></Link>
          <h1 className="font-display text-2xl font-bold">Budget Tracker</h1>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="bg-card border rounded-xl p-4">
            <p className="text-xs text-muted-foreground">Total Projected Costs</p>
            <p className="text-2xl font-bold text-foreground">${totalProjected.toLocaleString()}</p>
            <p className="text-xs text-muted-foreground mt-1">{regattas.length} regattas · {trips.length} trips</p>
          </div>
          <div className="bg-card border rounded-xl p-4">
            <p className="text-xs text-muted-foreground">Flights (all legs)</p>
            <p className="text-2xl font-bold">${totalFlightCosts.toLocaleString()}</p>
          </div>
          <div className="bg-card border rounded-xl p-4">
            <p className="text-xs text-muted-foreground">Confirmed Income</p>
            <p className="text-2xl font-bold text-green-600">${confirmedIncome.toLocaleString()}</p>
            {inKindIncome > 0 && <p className="text-xs text-muted-foreground mt-1">+${inKindIncome.toLocaleString()} in-kind</p>}
          </div>
          <div className={`border rounded-xl p-4 ${balance >= 0 ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"}`}>
            <p className="text-xs text-muted-foreground">Balance</p>
            <p className={`text-2xl font-bold ${balance >= 0 ? "text-green-600" : "text-red-500"}`}>
              {balance >= 0 ? "+" : "-"}${Math.abs(balance).toLocaleString()}
            </p>
            <p className={`text-xs mt-1 font-medium ${balance >= 0 ? "text-green-600" : "text-red-500"}`}>
              {balance >= 0 ? "Surplus" : "Deficit"}
            </p>
          </div>
        </div>

        {/* Form modals */}
        {showTripForm && (
          <TripForm
            trip={editingTrip}
            onClose={() => { setShowTripForm(false); setEditingTrip(null); }}
            onSaved={() => { setShowTripForm(false); setEditingTrip(null); qc.invalidateQueries({ queryKey: ["trips"] }); }}
          />
        )}
        {showRegattaForm && (
          <RegattaForm
            regatta={editingRegatta}
            tripId={regattaTripId}
            trips={trips}
            onClose={() => { setShowRegattaForm(false); setEditingRegatta(null); setRegattaTripId(null); }}
            onSaved={() => { setShowRegattaForm(false); setEditingRegatta(null); setRegattaTripId(null); qc.invalidateQueries({ queryKey: ["regattas"] }); }}
          />
        )}

        {/* Action buttons */}
        <div className="flex gap-3 mb-6 flex-wrap">
          <Button onClick={() => { setEditingTrip(null); setShowTripForm(true); }} className="bg-primary text-primary-foreground hover:opacity-90">
            <Plus className="w-4 h-4 mr-2" /><PlaneTakeoff className="w-4 h-4 mr-1" /> New Trip
          </Button>
          <Button onClick={() => openAddRegatta(null)} variant="outline">
            <Plus className="w-4 h-4 mr-2" /><Trophy className="w-4 h-4 mr-1" /> New Standalone Regatta
          </Button>
        </div>

        {/* Trips */}
        {trips.map((trip) => {
          const tripRegs = tripRegattas(trip.id);
          const regTotal = tripRegs.reduce((sum, r) => sum + calcRegattaTotal(r), 0);
          const flightTotal = calcTripFlightsTotal(trip);
          const tripTotal = regTotal + flightTotal;
          const isOpen = expandedTrips[trip.id];

          return (
            <div key={trip.id} className="bg-card border rounded-xl mb-4 overflow-hidden">
              <div
                className="flex items-center justify-between p-4 cursor-pointer hover:bg-muted/30 transition"
                onClick={() => toggleTrip(trip.id)}
              >
                <div className="flex items-center gap-3">
                  {isOpen ? <ChevronDown className="w-5 h-5 text-muted-foreground" /> : <ChevronRight className="w-5 h-5 text-muted-foreground" />}
                  <PlaneTakeoff className="w-5 h-5 text-primary" />
                  <div>
                    <span className="font-semibold">{trip.name}</span>
                    {trip.start_date && (
                      <span className="ml-3 text-xs text-muted-foreground">
                        {format(new Date(trip.start_date), "MMM d")}
                        {trip.end_date && ` – ${format(new Date(trip.end_date), "MMM d, yyyy")}`}
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-right hidden sm:block">
                    <p className="text-sm font-bold">${tripTotal.toLocaleString()}</p>
                    <p className="text-xs text-muted-foreground">{tripRegs.length} regatta{tripRegs.length !== 1 ? "s" : ""} · flights ${flightTotal.toLocaleString()}</p>
                  </div>
                  <div className="flex gap-1" onClick={(e) => e.stopPropagation()}>
                    <Button variant="ghost" size="icon" onClick={() => { setEditingTrip(trip); setShowTripForm(true); }}><Pencil className="w-3.5 h-3.5" /></Button>
                    <Button variant="ghost" size="icon" onClick={() => deleteTripMut.mutate(trip.id)}><Trash2 className="w-3.5 h-3.5 text-destructive" /></Button>
                  </div>
                </div>
              </div>

              {isOpen && (
                <div className="border-t px-4 pb-4 pt-3">
                  {trip.description && <p className="text-sm text-muted-foreground mb-4">{trip.description}</p>}

                  {/* Flight legs */}
                  {(trip.flight_legs || []).length > 0 && (
                    <div className="mb-4">
                      <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Flight Legs</p>
                      <div className="space-y-2">
                        {trip.flight_legs.map((leg, i) => (
                          <div key={leg.id || i} className="bg-blue-50 border border-blue-100 rounded-lg p-3 text-sm flex items-center justify-between flex-wrap gap-2">
                            <div className="flex items-center gap-2">
                              <PlaneTakeoff className="w-4 h-4 text-blue-600" />
                              <span className="font-medium">{leg.from} → {leg.to}</span>
                              {leg.date && <span className="text-muted-foreground">{format(new Date(leg.date), "MMM d")}</span>}
                            </div>
                            <div className="flex items-center gap-3 text-muted-foreground">
                              {leg.people_names && <span>{leg.people_names}</span>}
                              <span className="font-semibold text-foreground">${(leg.total_cost || 0).toLocaleString()}</span>
                              {leg.num_people > 0 && leg.cost_per_person > 0 && (
                                <span className="text-xs">({leg.num_people} × ${leg.cost_per_person.toLocaleString()})</span>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Regattas in this trip */}
                  <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Regattas</p>
                  {tripRegs.length === 0 ? (
                    <p className="text-sm text-muted-foreground mb-3">No regattas added yet.</p>
                  ) : (
                    <div className="space-y-2 mb-3">
                      {tripRegs.map((r) => (
                        <RegattaRow key={r.id} regatta={r} onEdit={() => openEditRegatta(r)} onDelete={() => deleteRegattaMut.mutate(r.id)} />
                      ))}
                    </div>
                  )}
                  <Button size="sm" variant="outline" onClick={() => openAddRegatta(trip.id)}>
                    <Plus className="w-3.5 h-3.5 mr-1" /> Add Regatta to Trip
                  </Button>
                </div>
              )}
            </div>
          );
        })}

        {/* Standalone regattas */}
        {standaloneRegattas.length > 0 && (
          <div className="bg-card border rounded-xl mb-4 overflow-hidden">
            <div
              className="flex items-center justify-between p-4 cursor-pointer hover:bg-muted/30 transition"
              onClick={() => setExpandedStandalones(!expandedStandalones)}
            >
              <div className="flex items-center gap-3">
                {expandedStandalones ? <ChevronDown className="w-5 h-5 text-muted-foreground" /> : <ChevronRight className="w-5 h-5 text-muted-foreground" />}
                <Trophy className="w-5 h-5 text-accent" />
                <span className="font-semibold">Standalone Regattas</span>
              </div>
              <span className="text-sm font-bold">${standaloneRegattas.reduce((s, r) => s + calcRegattaTotal(r), 0).toLocaleString()}</span>
            </div>
            {expandedStandalones && (
              <div className="border-t px-4 pb-4 pt-3 space-y-2">
                {standaloneRegattas.map((r) => (
                  <RegattaRow key={r.id} regatta={r} onEdit={() => openEditRegatta(r)} onDelete={() => deleteRegattaMut.mutate(r.id)} />
                ))}
              </div>
            )}
          </div>
        )}

        {trips.length === 0 && regattas.length === 0 && (
          <div className="text-center py-16 text-muted-foreground">
            <DollarSign className="w-10 h-10 mx-auto mb-3 opacity-30" />
            <p>No trips or regattas yet. Start by adding a Trip or Standalone Regatta.</p>
          </div>
        )}
      </div>
    </AdminGuard>
  );
}

function RegattaRow({ regatta: r, onEdit, onDelete }) {
  const total = calcRegattaTotal(r);
  return (
    <div className="bg-muted/30 border rounded-lg p-3 flex items-center justify-between flex-wrap gap-2">
      <div className="flex items-center gap-2">
        <Trophy className="w-4 h-4 text-accent" />
        <span className="font-medium text-sm">{r.name}</span>
        {r.location && <span className="text-xs text-muted-foreground">{r.location}{r.country ? `, ${r.country}` : ""}</span>}
        {r.start_date && <span className="text-xs text-muted-foreground">{format(new Date(r.start_date), "MMM d")}</span>}
        {r.status && <Badge className={`text-xs ${statusColors[r.status] || ""}`}>{r.status}</Badge>}
      </div>
      <div className="flex items-center gap-3">
        <div className="text-right">
          <span className="font-semibold text-sm">${total.toLocaleString()}</span>
          {r.num_people > 0 && <span className="text-xs text-muted-foreground ml-2">{r.num_people} people</span>}
        </div>
        <Button variant="ghost" size="icon" onClick={onEdit}><Pencil className="w-3.5 h-3.5" /></Button>
        <Button variant="ghost" size="icon" onClick={onDelete}><Trash2 className="w-3.5 h-3.5 text-destructive" /></Button>
      </div>
    </div>
  );
}

const statusColors = {
  Planned: "bg-blue-100 text-blue-700",
  Confirmed: "bg-green-100 text-green-700",
  Completed: "bg-gray-100 text-gray-700",
  Cancelled: "bg-red-100 text-red-700",
};