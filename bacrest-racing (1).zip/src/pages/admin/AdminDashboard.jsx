import React from "react";
import { Link } from "react-router-dom";
import AdminGuard from "@/components/admin/AdminGuard";
import { Users, PlaneTakeoff, Mail, Trophy, Anchor, Building2, TrendingUp, TrendingDown, ArrowRight, LayoutTemplate, Flag, Camera, Newspaper } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";

function calcRegattaTotal(r) {
  const accom = (r.accommodation_per_night || 0) * (r.accommodation_nights || 0);
  const food = (r.food_per_day_per_person || 0) * (r.event_days || 0) * (r.num_people || 1);
  return accom + food + (r.entry_fee || 0) + (r.training_fees || 0) + (r.equipment_costs || 0) + (r.other_costs || 0);
}

function calcTripFlights(trip) {
  return (trip.flight_legs || []).reduce((s, l) => s + (l.total_cost || 0), 0);
}

const modules = [
  { to: "/admin/sponsors", icon: Users, label: "Sponsor Tracker", desc: (d) => `${d.sponsors} sponsors tracked` },
  { to: "/admin/budget", icon: PlaneTakeoff, label: "Budget Tracker", desc: (d) => `${d.trips} trips · ${d.regattas} regattas` },
  { to: "/admin/messages", icon: Mail, label: "Messages", desc: (d) => `${d.unread} unread` },
  { to: "/admin/team", icon: Anchor, label: "Team Manager", desc: () => "Manage sailor profiles" },
  { to: "/admin/results", icon: Trophy, label: "Results Manager", desc: () => "Results & world rankings" },
  { to: "/admin/partners", icon: Building2, label: "Partners Manager", desc: () => "Manage sponsor logos & tiers" },
  { to: "/admin/campaign", icon: Flag, label: "Campaign Editor", desc: () => "Hero, stats & goals" },
  { to: "/admin/home", icon: LayoutTemplate, label: "Home Page Editor", desc: () => "Hero, pillars & copy" },
  { to: "/admin/media", icon: Camera, label: "Media Manager", desc: (d) => `${d.mediaCount} item${d.mediaCount !== 1 ? "s" : ""}` },
  { to: "/admin/news", icon: Newspaper, label: "News Manager", desc: (d) => `${d.newsCount} post${d.newsCount !== 1 ? "s" : ""}` },
];

export default function AdminDashboard() {
  const { data: sponsors = [] } = useQuery({ queryKey: ["sponsors-dash"], queryFn: () => base44.entities.SponsorTracker.list() });
  const { data: messages = [] } = useQuery({ queryKey: ["messages-dash"], queryFn: () => base44.entities.ContactMessage.list() });
  const { data: regattas = [] } = useQuery({ queryKey: ["regattas-dash"], queryFn: () => base44.entities.Regatta.list() });
  const { data: trips = [] } = useQuery({ queryKey: ["trips-dash"], queryFn: () => base44.entities.Trip.list() });
  const { data: mediaItems = [] } = useQuery({ queryKey: ["media-dash"], queryFn: () => base44.entities.MediaItem.list() });
  const { data: newsPosts = [] } = useQuery({ queryKey: ["news-dash"], queryFn: () => base44.entities.NewsPost.list() });

  const unread = messages.filter((m) => !m.read).length;
  const confirmedCash = sponsors.reduce((s, sp) => s + (sp.amount_confirmed || 0), 0);
  const confirmedInKind = sponsors.reduce((s, sp) => s + (sp.in_kind_value || 0), 0);
  const totalAsked = sponsors.reduce((s, sp) => s + (sp.amount_asked || 0), 0);
  const acceptedSponsors = sponsors.filter((s) => s.status === "Accepted").length;
  const toContact = sponsors.filter((s) => s.status === "To Contact").length;
  const totalCosts = regattas.reduce((s, r) => s + calcRegattaTotal(r), 0) + trips.reduce((s, t) => s + calcTripFlights(t), 0);
  const balance = confirmedCash - totalCosts;
  const coverage = totalCosts > 0 ? Math.round(((confirmedCash + confirmedInKind) / totalCosts) * 100) : 0;

  const descData = { sponsors: sponsors.length, trips: trips.length, regattas: regattas.length, unread, mediaCount: mediaItems.length, newsCount: newsPosts.length };

  return (
    <AdminGuard>
      <div className="max-w-5xl mx-auto px-6 py-16">

        {/* Header */}
        <div className="mb-12">
          <p className="text-xs font-600 tracking-[0.2em] uppercase text-crimson mb-2">Command Centre</p>
          <h1 className="font-display text-5xl font-800 uppercase tracking-wide text-white leading-none">Admin</h1>
          <div className="mt-4 w-12 h-px bg-crimson" />
        </div>

        {/* Balance bar */}
        <div className="border border-white/8 mb-px">
          <div className="px-8 py-6 flex flex-wrap items-center justify-between gap-6 bg-white/[0.02]">
            <div className="flex items-center gap-4">
              {balance >= 0
                ? <TrendingUp className="w-5 h-5 text-emerald-400" />
                : <TrendingDown className="w-5 h-5 text-crimson" />}
              <div>
                <p className="text-xs font-600 tracking-[0.15em] uppercase text-white/30 mb-1">Campaign Balance</p>
                <p className={`font-display text-4xl font-800 tracking-wide leading-none ${balance >= 0 ? "text-emerald-400" : "text-crimson"}`}>
                  {balance >= 0 ? "+" : "-"}${Math.abs(balance).toLocaleString()} NZD
                </p>
              </div>
            </div>
            <p className="text-xs text-white/30 tracking-wide">
              {balance >= 0 ? "Confirmed cash covers projected costs" : "Deficit — need more confirmed sponsors"}
            </p>
          </div>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-px bg-white/8 mb-12">
          {[
            { label: "Projected Costs", value: `$${totalCosts.toLocaleString()}`, sub: "NZD" },
            { label: "Confirmed Cash", value: `$${confirmedCash.toLocaleString()}`, sub: "NZD" },
            { label: "In-Kind Value", value: `$${confirmedInKind.toLocaleString()}`, sub: "NZD" },
            { label: "Pipeline", value: `$${totalAsked.toLocaleString()}`, sub: "NZD" },
          ].map((s) => (
            <div key={s.label} className="bg-background px-6 py-5">
              <p className="text-xs font-600 tracking-[0.15em] uppercase text-white/25 mb-2">{s.label}</p>
              <p className="font-display text-2xl font-700 text-white tracking-wide">{s.value}</p>
              <p className="text-xs text-white/20 mt-0.5">{s.sub}</p>
            </div>
          ))}
        </div>

        {/* Quick stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-px bg-white/8 mb-12">
          {[
            { label: "Total Sponsors", value: sponsors.length, sub: `${toContact} to contact · ${acceptedSponsors} accepted` },
            { label: "Regattas Planned", value: regattas.length, sub: `across ${trips.length} trip${trips.length !== 1 ? "s" : ""}` },
            { label: "Budget Coverage", value: `${coverage}%`, sub: "cash + in-kind vs costs" },
            { label: "Unread Messages", value: unread, sub: "contact form" },
          ].map((s) => (
            <div key={s.label} className="bg-background px-6 py-5">
              <p className="text-xs font-600 tracking-[0.15em] uppercase text-white/25 mb-2">{s.label}</p>
              <p className="font-display text-3xl font-800 text-white tracking-wide">{s.value}</p>
              <p className="text-xs text-white/20 mt-1">{s.sub}</p>
            </div>
          ))}
        </div>

        {/* Module links */}
        <div className="flex items-center gap-4 mb-6">
          <div className="w-2 h-2 bg-crimson" />
          <p className="text-xs font-700 tracking-[0.2em] uppercase text-white/40">Modules</p>
          <div className="flex-1 h-px bg-white/5" />
        </div>

        <div className="grid sm:grid-cols-3 gap-px bg-white/8">
          {modules.map(({ to, icon: Icon, label, desc }) => (
            <Link
              key={to}
              to={to}
              className="bg-background px-6 py-6 group hover:bg-white/[0.03] transition-colors flex items-center justify-between"
            >
              <div className="flex items-center gap-4">
                <Icon className="w-4 h-4 text-crimson flex-shrink-0" />
                <div>
                  <p className="font-display text-sm font-700 uppercase tracking-wide text-white/80 group-hover:text-white transition-colors">{label}</p>
                  <p className="text-xs text-white/25 mt-0.5 tracking-wide">{desc(descData)}</p>
                </div>
              </div>
              <ArrowRight className="w-3.5 h-3.5 text-white/20 group-hover:text-crimson group-hover:translate-x-1 transition-all" />
            </Link>
          ))}
        </div>

      </div>
    </AdminGuard>
  );
}