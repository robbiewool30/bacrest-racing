import React, { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import AdminGuard from "@/components/admin/AdminGuard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Pencil, Trash2, X, Save, Play, Image as ImageIcon, Upload, ChevronUp, ChevronDown, Check } from "lucide-react";

const empty = { title: "", album: "", type: "image", url: "", thumbnail_url: "", order: 0 };
const ORDER_KEY = "bacrest_album_order";

function loadAlbumOrder() {
  try { return JSON.parse(localStorage.getItem(ORDER_KEY) || "[]"); } catch { return []; }
}
function saveAlbumOrder(order) {
  localStorage.setItem(ORDER_KEY, JSON.stringify(order));
}

// Merge saved order with actual album names (new albums appended at end)
function mergeOrder(saved, actual) {
  const existing = saved.filter((a) => actual.includes(a));
  const newOnes = actual.filter((a) => !existing.includes(a));
  return [...existing, ...newOnes];
}

function MediaForm({ initial, onSave, onCancel }) {
  const [form, setForm] = useState({ ...empty, ...initial });
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const uploadFile = async (file) => {
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setUploading(false);
    return file_url;
  };

  const handleFileChange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    set("url", await uploadFile(file));
  };

  const handleThumbnailChange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    set("thumbnail_url", await uploadFile(file));
  };

  const handleDrop = async (e, field) => {
    e.preventDefault();
    e.stopPropagation();
    const file = e.dataTransfer.files[0];
    if (file) { set(field, await uploadFile(file)); return; }
    const url = e.dataTransfer.getData("text/plain") || e.dataTransfer.getData("text/uri-list");
    if (url) set(field, url);
  };

  const handlePaste = async (e, field) => {
    const items = Array.from(e.clipboardData.items);
    const imageItem = items.find((i) => i.type.startsWith("image/"));
    if (imageItem) {
      set(field, await uploadFile(imageItem.getAsFile()));
      return;
    }
    const textItem = items.find((i) => i.type === "text/plain");
    if (textItem) {
      textItem.getAsString((text) => { if (text.startsWith("http")) set(field, text); });
    }
  };

  const hasAlbum = form.album && form.album.trim();
  const canSave = form.url && (hasAlbum || form.title);

  const handleSave = async () => {
    if (!canSave) return;
    setSaving(true);
    const data = { ...form, order: Number(form.order) || 0 };
    if (initial?.id) {
      await base44.entities.MediaItem.update(initial.id, data);
    } else {
      await base44.entities.MediaItem.create(data);
    }
    setSaving(false);
    onSave();
  };

  return (
    <div className="border border-white/8 bg-white/[0.02] p-6 mb-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-display text-lg font-700 uppercase text-white/80">{initial?.id ? "Edit Item" : "Add Item"}</h3>
        <button onClick={onCancel}><X className="w-5 h-5 text-white/30 hover:text-white/60" /></button>
      </div>
      <div className="grid sm:grid-cols-2 gap-4">
        <div>
          <Label className="text-white/50 text-xs">Album / Event</Label>
          <Input value={form.album} onChange={(e) => set("album", e.target.value)} placeholder="e.g. Sailing World Cup 2026" />
        </div>
        <div>
          <Label className="text-white/50 text-xs">Title {hasAlbum ? "(optional)" : "*"}</Label>
          <Input value={form.title} onChange={(e) => set("title", e.target.value)} placeholder="e.g. Race Day — Auckland" />
        </div>
        <div>
          <Label className="text-white/50 text-xs">Type</Label>
          <Select value={form.type} onValueChange={(v) => set("type", v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="image">Photo</SelectItem>
              <SelectItem value="video">Video</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {form.type === "image" ? (
          <div className="sm:col-span-2">
            <Label className="text-white/50 text-xs">Photo *</Label>
            <label
              className="mt-1 flex flex-col items-center justify-center gap-2 cursor-pointer border border-dashed border-white/20 bg-white/[0.02] hover:bg-white/[0.05] px-4 py-6 transition-colors text-center"
              onDrop={(e) => handleDrop(e, "url")}
              onDragOver={(e) => e.preventDefault()}
              onPaste={(e) => handlePaste(e, "url")}
              tabIndex={0}
            >
              <Upload className="w-5 h-5 text-white/30" />
              <span className="text-sm text-white/40">
                {uploading ? "Uploading…" : form.url ? "Replace — click, drag & drop, or paste" : "Click, drag & drop, or paste photo"}
              </span>
              <input type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
            </label>
            {form.url && !uploading && (
              <img src={form.url} alt="preview" className="mt-2 h-24 object-cover" />
            )}
          </div>
        ) : (
          <>
            <div className="sm:col-span-2">
              <Label className="text-white/50 text-xs">Embed URL * (e.g. YouTube embed)</Label>
              <Input value={form.url} onChange={(e) => set("url", e.target.value)} placeholder="https://www.youtube.com/embed/..." />
            </div>
            <div className="sm:col-span-2">
              <Label className="text-white/50 text-xs">Thumbnail Photo (video preview)</Label>
              <label
                className="mt-1 flex flex-col items-center justify-center gap-2 cursor-pointer border border-dashed border-white/20 bg-white/[0.02] hover:bg-white/[0.05] px-4 py-5 transition-colors text-center"
                onDrop={(e) => handleDrop(e, "thumbnail_url")}
                onDragOver={(e) => e.preventDefault()}
                onPaste={(e) => handlePaste(e, "thumbnail_url")}
                tabIndex={0}
              >
                <Upload className="w-4 h-4 text-white/30" />
                <span className="text-sm text-white/40">
                  {uploading ? "Uploading…" : form.thumbnail_url ? "Replace — click, drag & drop, or paste" : "Click, drag & drop, or paste thumbnail"}
                </span>
                <input type="file" accept="image/*" className="hidden" onChange={handleThumbnailChange} />
              </label>
              {form.thumbnail_url && !uploading && (
                <img src={form.thumbnail_url} alt="thumbnail preview" className="mt-2 h-16 object-cover" />
              )}
            </div>
          </>
        )}

        <div>
          <Label className="text-white/50 text-xs">Display Order</Label>
          <Input type="number" value={form.order} onChange={(e) => set("order", e.target.value)} />
        </div>
      </div>
      <div className="flex gap-2 mt-5">
        <Button onClick={handleSave} disabled={saving || uploading || !canSave} className="bg-crimson hover:bg-crimson/90 text-white border-0">
          <Save className="w-4 h-4" /> {saving ? "Saving..." : "Save"}
        </Button>
        <Button variant="outline" onClick={onCancel}>Cancel</Button>
      </div>
    </div>
  );
}

// Inline upload zone for adding more photos to an existing album
function AlbumUploadZone({ albumName, onUploaded, onClose }) {
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState({ done: 0, total: 0 });

  const processFiles = async (files) => {
    const imageFiles = Array.from(files).filter((f) => f.type.startsWith("image/"));
    if (!imageFiles.length) return;
    setUploading(true);
    setProgress({ done: 0, total: imageFiles.length });
    for (let i = 0; i < imageFiles.length; i++) {
      const { file_url } = await base44.integrations.Core.UploadFile({ file: imageFiles[i] });
      await base44.entities.MediaItem.create({ title: "", album: albumName, type: "image", url: file_url, order: 0 });
      setProgress({ done: i + 1, total: imageFiles.length });
    }
    setUploading(false);
    setProgress({ done: 0, total: 0 });
    onUploaded();
    onClose();
  };

  return (
    <div className="mt-3 border border-dashed border-crimson/30 bg-crimson/[0.03] p-4 relative">
      <button className="absolute top-2 right-2" onClick={onClose}>
        <X className="w-4 h-4 text-white/30 hover:text-white/60" />
      </button>
      <p className="text-xs text-white/40 mb-2">Adding photos to <span className="text-crimson">{albumName}</span></p>
      <label
        className="flex flex-col items-center justify-center cursor-pointer border border-dashed border-white/10 bg-white/[0.01] hover:bg-white/[0.04] transition-colors text-center px-4 py-6"
        onDrop={(e) => { e.preventDefault(); processFiles(e.dataTransfer.files); }}
        onDragOver={(e) => e.preventDefault()}
      >
        <Upload className="w-5 h-5 text-white/25 mx-auto mb-2" />
        {uploading ? (
          <p className="text-sm text-white/50">Uploading {progress.done} / {progress.total}…</p>
        ) : (
          <p className="text-sm text-white/40">Drop photos here or click to select</p>
        )}
        <input type="file" accept="image/*" multiple className="hidden" onChange={(e) => processFiles(e.target.files)} />
      </label>
    </div>
  );
}

function BulkUploadZone({ onUploaded }) {
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState({ done: 0, total: 0 });
  const [album, setAlbum] = useState("");

  const processFiles = async (files) => {
    const imageFiles = Array.from(files).filter((f) => f.type.startsWith("image/"));
    if (!imageFiles.length) return;
    setUploading(true);
    setProgress({ done: 0, total: imageFiles.length });
    for (let i = 0; i < imageFiles.length; i++) {
      const { file_url } = await base44.integrations.Core.UploadFile({ file: imageFiles[i] });
      const title = album.trim() ? "" : imageFiles[i].name.replace(/\.[^.]+$/, "").replace(/[-_]/g, " ");
      await base44.entities.MediaItem.create({ title, album: album.trim(), type: "image", url: file_url, order: 0 });
      setProgress({ done: i + 1, total: imageFiles.length });
    }
    setUploading(false);
    setProgress({ done: 0, total: 0 });
    onUploaded();
  };

  return (
    <div className="border border-dashed border-white/20 bg-white/[0.02] p-6 mb-6">
      <div className="mb-4">
        <Label className="text-white/50 text-xs">Album / Event name (optional — groups photos together)</Label>
        <Input
          value={album}
          onChange={(e) => setAlbum(e.target.value)}
          placeholder="e.g. Sailing World Cup 2026"
          className="mt-1"
          disabled={uploading}
        />
      </div>
      <label
        className="flex flex-col items-center justify-center cursor-pointer border border-dashed border-white/10 bg-white/[0.01] hover:bg-white/[0.04] transition-colors text-center px-6 py-8"
        onDrop={(e) => { e.preventDefault(); processFiles(e.dataTransfer.files); }}
        onDragOver={(e) => e.preventDefault()}
      >
        <Upload className="w-6 h-6 text-white/25 mx-auto mb-2" />
        {uploading ? (
          <p className="text-sm text-white/50">Uploading {progress.done} / {progress.total}…</p>
        ) : (
          <>
            <p className="text-sm text-white/40">Drop multiple photos here or click to select</p>
            <p className="text-xs text-white/20 mt-1">All images will be added to the gallery automatically</p>
          </>
        )}
        <input type="file" accept="image/*" multiple className="hidden" onChange={(e) => processFiles(e.target.files)} />
      </label>
    </div>
  );
}

function ItemRow({ item, confirmDelete, setConfirmDelete, setEditing, deleteMutation }) {
  return (
    <div className="border border-white/5 bg-white/[0.01] p-4 flex items-center gap-4 hover:bg-white/[0.03] transition-colors">
      <div className="w-20 h-14 flex-shrink-0 overflow-hidden bg-white/5 relative">
        {item.type === "video" ? (
          <>
            {item.thumbnail_url && <img src={item.thumbnail_url} alt="" className="w-full h-full object-cover" />}
            <div className="absolute inset-0 flex items-center justify-center bg-black/40">
              <Play className="w-5 h-5 text-white" fill="white" />
            </div>
          </>
        ) : (
          <img src={item.url} alt="" className="w-full h-full object-cover" />
        )}
      </div>
      <div className="flex-1 min-w-0">
        {item.title
          ? <p className="font-semibold text-white/80 truncate">{item.title}</p>
          : <p className="text-white/25 italic text-sm truncate">No title</p>
        }
        <p className="text-xs text-white/25 mt-0.5 tracking-wide uppercase">{item.type}</p>
      </div>
      <div className="flex gap-2 flex-shrink-0">
        <Button variant="outline" size="icon" onClick={() => setEditing(item)}>
          <Pencil className="w-4 h-4" />
        </Button>
        {confirmDelete === item.id ? (
          <div className="flex gap-1">
            <Button variant="destructive" size="sm" onClick={() => deleteMutation.mutate(item.id)}>Delete</Button>
            <Button variant="outline" size="sm" onClick={() => setConfirmDelete(null)}>Cancel</Button>
          </div>
        ) : (
          <Button variant="outline" size="icon" onClick={() => setConfirmDelete(item.id)}>
            <Trash2 className="w-4 h-4 text-destructive" />
          </Button>
        )}
      </div>
    </div>
  );
}

export default function MediaManager() {
  const queryClient = useQueryClient();
  const [editing, setEditing] = useState(null);
  const [confirmDelete, setConfirmDelete] = useState(null);
  const [addingToAlbum, setAddingToAlbum] = useState(null); // album name
  const [renamingAlbum, setRenamingAlbum] = useState(null); // album name being renamed
  const [renameValue, setRenameValue] = useState("");
  const [albumOrder, setAlbumOrder] = useState(loadAlbumOrder);

  const { data: items = [] } = useQuery({
    queryKey: ["media"],
    queryFn: () => base44.entities.MediaItem.list("order"),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.MediaItem.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["media"] });
      setConfirmDelete(null);
    },
  });

  const handleSaved = () => {
    queryClient.invalidateQueries({ queryKey: ["media"] });
    setEditing(null);
  };

  // Group by album
  const albumMap = {};
  const ungrouped = [];
  for (const m of items) {
    const key = m.album && m.album.trim();
    if (key) {
      if (!albumMap[key]) albumMap[key] = [];
      albumMap[key].push(m);
    } else {
      ungrouped.push(m);
    }
  }

  const actualAlbumNames = Object.keys(albumMap);
  const orderedAlbums = mergeOrder(albumOrder, actualAlbumNames);

  const startRename = (name) => {
    setRenamingAlbum(name);
    setRenameValue(name);
  };

  const confirmRename = async () => {
    const newName = renameValue.trim();
    if (!newName || newName === renamingAlbum) { setRenamingAlbum(null); return; }
    const albumItems = albumMap[renamingAlbum] || [];
    await Promise.all(albumItems.map((item) => base44.entities.MediaItem.update(item.id, { ...item, album: newName })));
    // Update localStorage order too
    const newOrder = albumOrder.map((a) => (a === renamingAlbum ? newName : a));
    setAlbumOrder(newOrder);
    saveAlbumOrder(newOrder);
    setRenamingAlbum(null);
    queryClient.invalidateQueries({ queryKey: ["media"] });
  };

  const moveAlbum = (name, dir) => {
    const idx = orderedAlbums.indexOf(name);
    const newOrder = [...orderedAlbums];
    const swapIdx = idx + dir;
    if (swapIdx < 0 || swapIdx >= newOrder.length) return;
    [newOrder[idx], newOrder[swapIdx]] = [newOrder[swapIdx], newOrder[idx]];
    setAlbumOrder(newOrder);
    saveAlbumOrder(newOrder);
  };

  const rowProps = { confirmDelete, setConfirmDelete, setEditing, deleteMutation };

  return (
    <AdminGuard>
      <div className="max-w-4xl mx-auto px-6 py-16">
        <div className="mb-10">
          <p className="text-xs font-600 tracking-[0.2em] uppercase text-crimson mb-2">Admin</p>
          <h1 className="font-display text-4xl font-800 uppercase tracking-wide text-white leading-none">Media Manager</h1>
          <div className="mt-4 w-12 h-px bg-crimson" />
        </div>

        {editing && (
          <MediaForm initial={editing} onSave={handleSaved} onCancel={() => setEditing(null)} />
        )}

        {!editing && (
          <BulkUploadZone onUploaded={() => queryClient.invalidateQueries({ queryKey: ["media"] })} />
        )}

        <div className="mb-6 flex items-center gap-3">
          {!editing && (
            <Button variant="outline" onClick={() => setEditing({})}>
              <Plus className="w-4 h-4" /> Add Single Item
            </Button>
          )}
          <p className="text-xs text-white/25 tracking-wide">{items.length} item{items.length !== 1 ? "s" : ""}</p>
        </div>

        {items.length === 0 && !editing ? (
          <div className="text-center py-16 border border-white/5">
            <ImageIcon className="w-10 h-10 text-white/10 mx-auto mb-3" />
            <p className="text-white/25 text-sm">No media items yet.</p>
          </div>
        ) : (
          <div className="space-y-8">
            {orderedAlbums.map((album, idx) => {
              const albumItems = albumMap[album];
              if (!albumItems) return null;
              return (
                <div key={album}>
                  <div className="flex items-center gap-3 mb-3">
                    {/* Up/Down order controls */}
                    <div className="flex flex-col gap-0.5">
                      <button
                        onClick={() => moveAlbum(album, -1)}
                        disabled={idx === 0}
                        className="text-white/20 hover:text-white/60 disabled:opacity-20 disabled:cursor-not-allowed transition-colors"
                      >
                        <ChevronUp className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => moveAlbum(album, 1)}
                        disabled={idx === orderedAlbums.length - 1}
                        className="text-white/20 hover:text-white/60 disabled:opacity-20 disabled:cursor-not-allowed transition-colors"
                      >
                        <ChevronDown className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <div className="w-1.5 h-1.5 bg-crimson rounded-full flex-shrink-0" />
                    {renamingAlbum === album ? (
                      <div className="flex items-center gap-2 flex-1">
                        <Input
                          value={renameValue}
                          onChange={(e) => setRenameValue(e.target.value)}
                          onKeyDown={(e) => { if (e.key === "Enter") confirmRename(); if (e.key === "Escape") setRenamingAlbum(null); }}
                          className="h-7 text-xs py-0 px-2 w-56"
                          autoFocus
                        />
                        <button onClick={confirmRename} className="text-crimson hover:text-crimson/80 transition-colors">
                          <Save className="w-3.5 h-3.5" />
                        </button>
                        <button onClick={() => setRenamingAlbum(null)} className="text-white/30 hover:text-white/60 transition-colors">
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <>
                        <p className="text-xs font-700 tracking-[0.15em] uppercase text-crimson">{album}</p>
                        <button onClick={() => startRename(album)} className="text-white/20 hover:text-white/50 transition-colors">
                          <Pencil className="w-3 h-3" />
                        </button>
                      </>
                    )}
                    <span className="text-xs text-white/20">{albumItems.length} photo{albumItems.length !== 1 ? "s" : ""}</span>
                    <button
                      className="ml-auto flex items-center gap-1.5 text-xs text-white/30 hover:text-white/60 transition-colors"
                      onClick={() => setAddingToAlbum(addingToAlbum === album ? null : album)}
                    >
                      <Plus className="w-3.5 h-3.5" /> Add photos
                    </button>
                  </div>

                  {addingToAlbum === album && (
                    <AlbumUploadZone
                      albumName={album}
                      onUploaded={() => queryClient.invalidateQueries({ queryKey: ["media"] })}
                      onClose={() => setAddingToAlbum(null)}
                    />
                  )}

                  <div className="space-y-px border-l-2 border-crimson/20 pl-4">
                    {albumItems.map((item) => <ItemRow key={item.id} item={item} {...rowProps} />)}
                  </div>
                </div>
              );
            })}

            {ungrouped.length > 0 && (
              <div>
                {orderedAlbums.length > 0 && (
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-1.5 h-1.5 bg-white/20 rounded-full" />
                    <p className="text-xs font-700 tracking-[0.15em] uppercase text-white/30">No Album</p>
                    <span className="text-xs text-white/20">{ungrouped.length} item{ungrouped.length !== 1 ? "s" : ""}</span>
                  </div>
                )}
                <div className={orderedAlbums.length > 0 ? "space-y-px border-l-2 border-white/10 pl-4" : "space-y-px"}>
                  {ungrouped.map((item) => <ItemRow key={item.id} item={item} {...rowProps} />)}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </AdminGuard>
  );
}