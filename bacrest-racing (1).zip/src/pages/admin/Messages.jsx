import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import AdminGuard from "@/components/admin/AdminGuard";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Mail, MailOpen, Trash2 } from "lucide-react";
import { Link } from "react-router-dom";
import { format } from "date-fns";

export default function Messages() {
  const qc = useQueryClient();
  const { data: messages = [] } = useQuery({
    queryKey: ["admin-messages"],
    queryFn: () => base44.entities.ContactMessage.list("-created_date"),
  });

  const markRead = useMutation({
    mutationFn: (msg) => base44.entities.ContactMessage.update(msg.id, { ...msg, read: true }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["admin-messages"] }),
  });

  const deleteMut = useMutation({
    mutationFn: (id) => base44.entities.ContactMessage.delete(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["admin-messages"] }),
  });

  return (
    <AdminGuard>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
        <div className="flex items-center gap-3 mb-6">
          <Link to="/admin" className="text-muted-foreground hover:text-foreground"><ArrowLeft className="w-5 h-5" /></Link>
          <h1 className="font-display text-2xl font-bold">Contact Messages</h1>
        </div>

        {messages.length === 0 ? (
          <p className="text-center text-muted-foreground py-12">No messages yet.</p>
        ) : (
          <div className="space-y-4">
            {messages.map((m) => (
              <div key={m.id} className={`bg-card border rounded-xl p-5 ${!m.read ? "border-accent/30 bg-accent/5" : ""}`}>
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      {m.read ? <MailOpen className="w-4 h-4 text-muted-foreground" /> : <Mail className="w-4 h-4 text-accent" />}
                      <span className="font-semibold">{m.name}</span>
                      <span className="text-sm text-muted-foreground">{m.email}</span>
                      {!m.read && <Badge className="bg-accent text-accent-foreground text-xs">New</Badge>}
                    </div>
                    {m.subject && <p className="text-sm font-medium mb-1">{m.subject}</p>}
                    <p className="text-sm text-muted-foreground">{m.message}</p>
                    <p className="text-xs text-muted-foreground mt-2">
                      {m.created_date ? format(new Date(m.created_date), "MMM d, yyyy 'at' h:mm a") : ""}
                    </p>
                  </div>
                  <div className="flex gap-1">
                    {!m.read && (
                      <Button variant="ghost" size="icon" onClick={() => markRead.mutate(m)}>
                        <MailOpen className="w-3.5 h-3.5" />
                      </Button>
                    )}
                    <Button variant="ghost" size="icon" onClick={() => deleteMut.mutate(m.id)}>
                      <Trash2 className="w-3.5 h-3.5 text-destructive" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </AdminGuard>
  );
}