import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import AdminGuard from "@/components/admin/AdminGuard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Pencil, Trash2, X, Save, Trophy, Globe } from "lucide-react";

import { format } from "date-fns";

const emptyResult = { event_name: "", racing_type: "Match Racing", location: "", date: "", placement: "", fleet_size: "", notes: "" };

function ResultForm({ initial, onSave, onCancel }) {
  const [form, setForm] = useState({ ...emptyResult, ...initial });
  const [saving, setSaving] = useState(false);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const handleSave = async () => {
    setSaving(true);
    const data = { ...form, fleet_size: form.fleet_size ? Number(form.fleet_size) : null };
    if (initial?.id) await base44.entities.Result.update(initial.id, data);
    else await base44.entities.Result.create(data);
    setSaving(false);
    onSave();
  };

  return (
    <div className="bg-card border rounded-xl p-5 mb-4">
      <div className="flex items-center justify-between mb-4">
        <h4 className="font-semibold">{initial?.id ? "Edit Result" : "Add Result"}</h4>
        <button onClick={onCancel}><X className="w-4 h-4 text-muted-foreground" /></button>
      </div>
      <div className="grid sm:grid-cols-2 gap-3">
        <div><Label>Event Name *</Label><Input value={form.event_name} onChange={(e) => set("event_name", e.target.value)} /></div>
        <div>
          <Label>Racing Type</Label>
          <Select value={form.racing_type} onValueChange={(v) => set("racing_type", v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="Match Racing">Match Racing</SelectItem>
              <SelectItem value="Fleet Racing">Fleet Racing</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div><Label>Location</Label><Input value={form.location} onChange={(e) => set("location", e.target.value)} /></div>
        <div><Label>Date</Label><Input type="date" value={form.date} onChange={(e) => set("date", e.target.value)} /></div>
        <div><Label>Placement</Label><Input value={form.placement} onChange={(e) => set("placement", e.target.value)} placeholder="e.g. 1st, 2nd" /></div>
        <div><Label>Fleet Size</Label><Input type="number" value={form.fleet_size} onChange={(e) => set("fleet_size", e.target.value)} /></div>
        <div><Label>Notes</Label><Input value={form.notes} onChange={(e) => set("notes", e.target.value)} /></div>
      </div>
      <div className="flex gap-2 mt-4">
        <Button onClick={handleSave} disabled={saving || !form.event_name}><Save className="w-4 h-4" />{saving ? "Saving..." : "Save"}</Button>
        <Button variant="outline" onClick={onCancel}>Cancel</Button>
      </div>
    </div>
  );
}

function RankingCard({ type, ranking, onSave }) {
  const [rank, setRank] = useState(ranking?.rank ?? "");
  const [date, setDate] = useState(ranking?.as_of_date ?? "");
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    const data = { ranking_type: type, rank: Number(rank), as_of_date: date };
    if (ranking?.id) await base44.entities.WorldRanking.update(ranking.id, data);
    else await base44.entities.WorldRanking.create(data);
    setSaving(false);
    onSave();
  };

  return (
    <div className="bg-card border rounded-xl p-5">
      <h3 className="font-display font-semibold text-lg mb-4 flex items-center gap-2">
        <Globe className="w-5 h-5 text-accent" /> {type} Ranking
      </h3>
      <div className="space-y-3">
        <div><Label>World Rank</Label><Input type="number" value={rank} onChange={(e) => setRank(e.target.value)} placeholder="e.g. 42" /></div>
        <div><Label>Last Updated</Label><Input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></div>
      </div>
      <Button className="mt-4" onClick={handleSave} disabled={saving || !rank}>
        <Save className="w-4 h-4" />{saving ? "Saving..." : "Save"}
      </Button>
    </div>
  );
}

export default function ResultsManager() {
  const queryClient = useQueryClient();
  const [editingResult, setEditingResult] = useState(null);
  const [confirmDelete, setConfirmDelete] = useState(null);

  const { data: results = [] } = useQuery({ queryKey: ["results"], queryFn: () => base44.entities.Result.list("-date") });
  const { data: rankings = [] } = useQuery({ queryKey: ["rankings"], queryFn: () => base44.entities.WorldRanking.list() });

  const youthRanking = rankings.find((r) => r.ranking_type === "Youth");
  const openRanking = rankings.find((r) => r.ranking_type === "Open");

  const deleteResult = useMutation({ mutationFn: (id) => base44.entities.Result.delete(id), onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["results"] }); setConfirmDelete(null); } });

  const savedResult = () => { queryClient.invalidateQueries({ queryKey: ["results"] }); setEditingResult(null); };
  const savedRanking = () => { queryClient.invalidateQueries({ queryKey: ["rankings"] }); };

  return (
    <AdminGuard>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-12">
        <h1 className="font-display text-3xl font-bold mb-8">Results Manager</h1>

        {/* World Rankings */}
        <div className="mb-12">
          <h2 className="font-display text-xl font-semibold mb-4 flex items-center gap-2">
            <Globe className="w-5 h-5 text-accent" /> World Sailing Rankings
          </h2>
          <div className="grid sm:grid-cols-2 gap-4">
            <RankingCard type="Youth" ranking={youthRanking} onSave={savedRanking} />
            <RankingCard type="Open" ranking={openRanking} onSave={savedRanking} />
          </div>
        </div>

        {/* Race Results */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display text-xl font-semibold flex items-center gap-2"><Trophy className="w-5 h-5 text-accent" /> Race Results</h2>
            {!editingResult && (
              <Button size="sm" onClick={() => setEditingResult({})}><Plus className="w-4 h-4" /> Add Result</Button>
            )}
          </div>

          {editingResult && (
            <ResultForm initial={editingResult} onSave={savedResult} onCancel={() => setEditingResult(null)} />
          )}

          {results.length === 0 && !editingResult ? (
            <p className="text-muted-foreground text-sm">No results added yet.</p>
          ) : (
            <div className="space-y-2">
              {results.map((r) => (
                <div key={r.id} className="bg-card border rounded-xl px-4 py-3 flex items-center gap-4">
                  <Trophy className="w-5 h-5 text-accent flex-shrink-0" />
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <p className="font-semibold">{r.event_name}</p>
                      {r.racing_type && (
                        <span className="text-xs px-2 py-0.5 rounded-full bg-accent/10 text-accent font-medium">{r.racing_type}</span>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {r.placement && <span className="font-semibold text-accent">{r.placement} </span>}
                      {r.fleet_size && `/ ${r.fleet_size} · `}{r.location}{r.date ? ` · ${format(new Date(r.date), "MMM d, yyyy")}` : ""}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="icon" onClick={() => setEditingResult(r)}><Pencil className="w-4 h-4" /></Button>
                    {confirmDelete === r.id ? (
                      <><Button variant="destructive" size="sm" onClick={() => deleteResult.mutate(r.id)}>Delete</Button><Button variant="outline" size="sm" onClick={() => setConfirmDelete(null)}>Cancel</Button></>
                    ) : (
                      <Button variant="outline" size="icon" onClick={() => setConfirmDelete(r.id)}><Trash2 className="w-4 h-4 text-destructive" /></Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </AdminGuard>
  );
}