import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import AdminGuard from "@/components/admin/AdminGuard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { User, Plus, Pencil, Trash2, X, Save, Upload } from "lucide-react";
import { Link } from "react-router-dom";

const empty = {
  name: "", role: "", bio: "", photo_url: "", nationality: "", hometown: "",
  sailing_experience: "", notable_results: "",
  instagram_url: "", order: 0, gallery_photos: [],
};

function MemberForm({ initial, onSave, onCancel }) {
  const [form, setForm] = useState({ ...empty, ...initial });
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const uploadFile = async (file) => {
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setUploading(false);
    return file_url;
  };

  const handleImageInput = async (file, field) => {
    if (file) set(field, await uploadFile(file));
  };

  const handleDrop = async (e, field) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file) { set(field, await uploadFile(file)); return; }
    const url = e.dataTransfer.getData("text/plain");
    if (url) set(field, url);
  };

  const handlePaste = async (e, field) => {
    const items = Array.from(e.clipboardData.items);
    const imgItem = items.find((i) => i.type.startsWith("image/"));
    if (imgItem) { set(field, await uploadFile(imgItem.getAsFile())); return; }
    const textItem = items.find((i) => i.type === "text/plain");
    if (textItem) textItem.getAsString((t) => { if (t.startsWith("http")) set(field, t); });
  };

  const handleGalleryDrop = async (e, idx) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    const updated = [...(form.gallery_photos || [])];
    if (file) { updated[idx] = await uploadFile(file); set("gallery_photos", updated); return; }
    const url = e.dataTransfer.getData("text/plain");
    if (url) { updated[idx] = url; set("gallery_photos", updated); }
  };

  const handleGalleryPaste = async (e, idx) => {
    const items = Array.from(e.clipboardData.items);
    const imgItem = items.find((i) => i.type.startsWith("image/"));
    const updated = [...(form.gallery_photos || [])];
    if (imgItem) { updated[idx] = await uploadFile(imgItem.getAsFile()); set("gallery_photos", updated); return; }
    const textItem = items.find((i) => i.type === "text/plain");
    if (textItem) textItem.getAsString((t) => { if (t.startsWith("http")) { updated[idx] = t; set("gallery_photos", updated); } });
  };

  const addGalleryPhotos = async (e) => {
    const files = Array.from(e.target.files);
    if (!files.length) return;
    const urls = [];
    for (const file of files) {
      urls.push(await uploadFile(file));
    }
    set("gallery_photos", [...(form.gallery_photos || []), ...urls]);
  };

  const handleSave = async () => {
    if (!form.name) return;
    setSaving(true);
    const data = {
      ...form,
      order: form.order ? Number(form.order) : 0,
    };
    if (initial?.id) {
      await base44.entities.TeamMember.update(initial.id, data);
    } else {
      await base44.entities.TeamMember.create(data);
    }
    setSaving(false);
    onSave();
  };

  return (
    <div className="bg-card border rounded-xl p-6 mb-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-lg">{initial?.id ? "Edit Sailor" : "Add Sailor"}</h3>
        <button onClick={onCancel}><X className="w-5 h-5 text-muted-foreground hover:text-foreground" /></button>
      </div>

      <div className="grid sm:grid-cols-2 gap-4">
        <div><Label>Name *</Label><Input value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="Full name" /></div>
        <div><Label>Role *</Label><Input value={form.role} onChange={(e) => set("role", e.target.value)} placeholder="e.g. Helm, Tactician, Bowman..." /></div>
        <div><Label>Hometown</Label><Input value={form.hometown} onChange={(e) => set("hometown", e.target.value)} placeholder="e.g. Auckland, NZ" /></div>
        <div><Label>Nationality</Label><Input value={form.nationality} onChange={(e) => set("nationality", e.target.value)} placeholder="e.g. New Zealand" /></div>
        <div>
          <Label>Profile Photo</Label>
          <label
            className="mt-1 flex flex-col items-center justify-center gap-1 cursor-pointer border border-dashed border-white/20 bg-white/[0.02] hover:bg-white/[0.04] px-4 py-4 transition-colors text-center"
            onDrop={(e) => handleDrop(e, "photo_url")}
            onDragOver={(e) => e.preventDefault()}
            onPaste={(e) => handlePaste(e, "photo_url")}
            tabIndex={0}
          >
            {form.photo_url ? (
              <img src={form.photo_url} alt="preview" className="h-16 w-16 rounded-full object-cover mb-1" />
            ) : (
              <Upload className="w-5 h-5 text-white/30" />
            )}
            <span className="text-xs text-white/40">{uploading ? "Uploading…" : form.photo_url ? "Replace — click, drag & drop, or paste" : "Click, drag & drop, or paste"}</span>
            <input type="file" accept="image/*" className="hidden" onChange={(e) => handleImageInput(e.target.files[0], "photo_url")} />
          </label>
        </div>
        <div><Label>Instagram URL</Label><Input value={form.instagram_url} onChange={(e) => set("instagram_url", e.target.value)} placeholder="https://instagram.com/..." /></div>
        <div className="sm:col-span-2"><Label>Bio / Blurb</Label><Textarea value={form.bio} onChange={(e) => set("bio", e.target.value)} rows={3} placeholder="Short bio shown on the team page..." /></div>
        <div className="sm:col-span-2"><Label>Sailing Experience</Label><Textarea value={form.sailing_experience} onChange={(e) => set("sailing_experience", e.target.value)} rows={4} placeholder="Background, clubs, training, programmes..." /></div>
        <div className="sm:col-span-2"><Label>Notable Results</Label><Textarea value={form.notable_results} onChange={(e) => set("notable_results", e.target.value)} rows={4} placeholder="Key results, podiums, championships..." /></div>
        <div><Label>Display Order</Label><Input type="number" value={form.order} onChange={(e) => set("order", e.target.value)} /></div>

        {/* Gallery Photos */}
        <div className="sm:col-span-2">
          <Label>Gallery Photos</Label>
          <div
            className="mt-2 grid grid-cols-3 sm:grid-cols-4 gap-2"
            onDrop={async (e) => {
              e.preventDefault();
              const files = Array.from(e.dataTransfer.files).filter((f) => f.type.startsWith("image/"));
              if (!files.length) return;
              const urls = [];
              for (const file of files) urls.push(await uploadFile(file));
              set("gallery_photos", [...(form.gallery_photos || []), ...urls]);
            }}
            onDragOver={(e) => e.preventDefault()}
          >
            {(form.gallery_photos || []).map((url, i) => (
              <div key={i} className="relative group">
                <label
                  className="block cursor-pointer border border-dashed border-white/20 bg-white/[0.02] hover:bg-white/[0.04] transition-colors"
                  onDrop={(e) => handleGalleryDrop(e, i)}
                  onDragOver={(e) => e.preventDefault()}
                  onPaste={(e) => handleGalleryPaste(e, i)}
                  tabIndex={0}
                >
                  {url ? (
                    <img src={url} alt="" className="w-full aspect-square object-cover" />
                  ) : (
                    <div className="w-full aspect-square flex items-center justify-center">
                      <Upload className="w-4 h-4 text-white/20" />
                    </div>
                  )}
                  <input type="file" accept="image/*" className="hidden" onChange={async (e) => {
                    const file = e.target.files[0];
                    if (!file) return;
                    const uploaded = await uploadFile(file);
                    const updated = [...(form.gallery_photos || [])];
                    updated[i] = uploaded;
                    set("gallery_photos", updated);
                  }} />
                </label>
                <button
                  type="button"
                  className="absolute top-1 right-1 bg-black/60 rounded-full p-0.5 opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={() => set("gallery_photos", (form.gallery_photos || []).filter((_, idx) => idx !== i))}
                >
                  <X className="w-3 h-3 text-white" />
                </button>
              </div>
            ))}
            {/* Add new — multi-select */}
            <label className="cursor-pointer border border-dashed border-white/15 bg-white/[0.01] hover:bg-white/[0.04] transition-colors flex flex-col items-center justify-center aspect-square gap-1">
              <Upload className="w-4 h-4 text-white/25" />
              <span className="text-xs text-white/25 text-center leading-tight px-1">Add photos</span>
              <input type="file" accept="image/*" multiple className="hidden" onChange={addGalleryPhotos} />
            </label>
          </div>
        </div>
      </div>

      <div className="flex gap-2 mt-5">
        <Button onClick={handleSave} disabled={saving || !form.name}>
          <Save className="w-4 h-4" />{saving ? "Saving..." : "Save Sailor"}
        </Button>
        <Button variant="outline" onClick={onCancel}>Cancel</Button>
      </div>
    </div>
  );
}

export default function TeamManager() {
  const queryClient = useQueryClient();
  const [editing, setEditing] = useState(null); // null = closed, {} = new, member = edit
  const [confirmDelete, setConfirmDelete] = useState(null);

  const { data: members = [] } = useQuery({
    queryKey: ["team-members"],
    queryFn: () => base44.entities.TeamMember.list("order"),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.TeamMember.delete(id),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["team-members"] }); setConfirmDelete(null); },
  });

  const handleSaved = () => {
    queryClient.invalidateQueries({ queryKey: ["team-members"] });
    setEditing(null);
  };

  return (
    <AdminGuard>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-12">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="font-display text-3xl font-bold">Team Manager</h1>
            <p className="text-muted-foreground mt-1">{members.length} sailor{members.length !== 1 ? "s" : ""} on the team</p>
          </div>
          {!editing && (
            <Button onClick={() => setEditing({})}>
              <Plus className="w-4 h-4" /> Add Sailor
            </Button>
          )}
        </div>

        {editing && (
          <MemberForm
            initial={editing}
            onSave={handleSaved}
            onCancel={() => setEditing(null)}
          />
        )}

        {members.length === 0 && !editing ? (
          <div className="text-center py-16 bg-card border rounded-xl">
            <User className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground">No sailors added yet.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {members.map((m) => (
              <div key={m.id} className="bg-card border rounded-xl p-4 flex items-center gap-4">
                {m.photo_url ? (
                  <img src={m.photo_url} alt={m.name} className="w-14 h-14 rounded-full object-cover flex-shrink-0" />
                ) : (
                  <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <User className="w-6 h-6 text-primary/40" />
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="font-semibold">{m.name}</p>
                    <span className="text-xs bg-accent/10 text-accent px-2 py-0.5 rounded-full font-semibold">{m.role}</span>
                  </div>
                  {m.bio && <p className="text-sm text-muted-foreground mt-0.5 truncate">{m.bio}</p>}
                  <Link to={`/sailor/${m.id}`} className="text-xs text-primary hover:underline mt-0.5 inline-block">View public profile →</Link>
                </div>
                <div className="flex gap-2 flex-shrink-0">
                  <Button variant="outline" size="icon" onClick={() => setEditing(m)}>
                    <Pencil className="w-4 h-4" />
                  </Button>
                  {confirmDelete === m.id ? (
                    <div className="flex gap-1">
                      <Button variant="destructive" size="sm" onClick={() => deleteMutation.mutate(m.id)}>Delete</Button>
                      <Button variant="outline" size="sm" onClick={() => setConfirmDelete(null)}>Cancel</Button>
                    </div>
                  ) : (
                    <Button variant="outline" size="icon" onClick={() => setConfirmDelete(m.id)}>
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </AdminGuard>
  );
}