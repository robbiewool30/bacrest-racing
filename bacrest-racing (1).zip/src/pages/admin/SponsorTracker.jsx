import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import AdminGuard from "@/components/admin/AdminGuard";
import SponsorForm from "@/components/admin/SponsorForm";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Pencil, Trash2, AlertTriangle, ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { format } from "date-fns";

const statusColors = {
  "To Contact": "bg-muted text-muted-foreground",
  "Contacted": "bg-blue-100 text-blue-700",
  "In Discussion": "bg-yellow-100 text-yellow-700",
  "Proposal Sent": "bg-purple-100 text-purple-700",
  "Accepted": "bg-green-100 text-green-700",
  "Declined": "bg-red-100 text-red-700",
  "Follow Up": "bg-orange-100 text-orange-700",
};

export default function SponsorTrackerPage() {
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [filterCat, setFilterCat] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterRole, setFilterRole] = useState("all");
  const qc = useQueryClient();

  const { data: sponsors = [] } = useQuery({
    queryKey: ["sponsor-tracker"],
    queryFn: () => base44.entities.SponsorTracker.list("company_name"),
  });

  const deleteMut = useMutation({
    mutationFn: (id) => base44.entities.SponsorTracker.delete(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["sponsor-tracker"] }),
  });

  const filtered = sponsors.filter((s) => {
    if (filterCat !== "all" && s.category !== filterCat) return false;
    if (filterStatus !== "all" && s.status !== filterStatus) return false;
    if (filterRole !== "all" && s.partner_role !== filterRole) return false;
    return true;
  });

  const partnerRoles = [...new Set(sponsors.filter(s => s.partner_role).map(s => s.partner_role))].sort();

  const totalAsked = filtered.reduce((a, s) => a + (s.amount_asked || 0), 0);
  const totalConfirmed = filtered.reduce((a, s) => a + (s.amount_confirmed || 0), 0);
  const totalInKind = filtered.reduce((a, s) => a + (s.in_kind_value || 0), 0);

  return (
    <AdminGuard>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        <div className="flex items-center gap-3 mb-6">
          <Link to="/admin" className="text-muted-foreground hover:text-foreground"><ArrowLeft className="w-5 h-5" /></Link>
          <h1 className="font-display text-2xl font-bold">Sponsor Tracker</h1>
        </div>

        {/* Summary */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
          <div className="bg-card border rounded-lg p-4">
            <p className="text-xs text-muted-foreground">Total Sponsors</p>
            <p className="text-2xl font-bold">{filtered.length}</p>
          </div>
          <div className="bg-card border rounded-lg p-4">
            <p className="text-xs text-muted-foreground">Total Asked</p>
            <p className="text-2xl font-bold">${totalAsked.toLocaleString()}</p>
          </div>
          <div className="bg-card border rounded-lg p-4">
            <p className="text-xs text-muted-foreground">Confirmed Cash</p>
            <p className="text-2xl font-bold text-green-600">${totalConfirmed.toLocaleString()}</p>
          </div>
          <div className="bg-card border rounded-lg p-4">
            <p className="text-xs text-muted-foreground">In-Kind Value</p>
            <p className="text-2xl font-bold text-accent">${totalInKind.toLocaleString()}</p>
          </div>
        </div>

        {/* Filters + Add */}
        <div className="flex flex-wrap items-center gap-3 mb-4">
          <Select value={filterCat} onValueChange={setFilterCat}>
            <SelectTrigger className="w-40"><SelectValue placeholder="Category" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {["Platinum", "Gold", "Silver", "Official Partner", "Preferred", "Other"].map((c) => (
                <SelectItem key={c} value={c}>{c}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-40"><SelectValue placeholder="Status" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              {Object.keys(statusColors).map((s) => (
                <SelectItem key={s} value={s}>{s}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          {filterCat === "Official Partner" || filterCat === "all" ? (
            <Select value={filterRole} onValueChange={setFilterRole}>
              <SelectTrigger className="w-48"><SelectValue placeholder="Partner Role" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Partner Roles</SelectItem>
                {partnerRoles.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}
              </SelectContent>
            </Select>
          ) : null}
          <div className="flex-1" />
          <Button onClick={() => { setEditing(null); setShowForm(true); }} className="bg-accent text-accent-foreground hover:opacity-90">
            <Plus className="w-4 h-4 mr-2" /> Add Sponsor
          </Button>
        </div>

        {showForm && (
          <SponsorForm
            sponsor={editing}
            onClose={() => { setShowForm(false); setEditing(null); }}
            onSaved={() => { setShowForm(false); setEditing(null); qc.invalidateQueries({ queryKey: ["sponsor-tracker"] }); }}
          />
        )}

        {/* Table */}
        <div className="bg-card border rounded-xl overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead>Company</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Partner Role</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Type</TableHead>
                <TableHead className="text-right">Asked</TableHead>
                <TableHead className="text-right">Confirmed</TableHead>
                <TableHead>Last Contact</TableHead>
                <TableHead>Priority</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((s) => (
                <TableRow key={s.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-2">
                      {s.company_name}
                      {s.ytp_conflict && <AlertTriangle className="w-3.5 h-3.5 text-yellow-500" title="YTP conflict" />}
                    </div>
                  </TableCell>
                  <TableCell><Badge variant="secondary" className="text-xs">{s.category}</Badge></TableCell>
                  <TableCell className="text-sm text-muted-foreground">{s.partner_role || "—"}</TableCell>
                  <TableCell><Badge className={`text-xs ${statusColors[s.status] || ""}`}>{s.status}</Badge></TableCell>
                  <TableCell className="text-sm">{s.type || "—"}</TableCell>
                  <TableCell className="text-right text-sm">{s.amount_asked ? `$${s.amount_asked.toLocaleString()}` : "—"}</TableCell>
                  <TableCell className="text-right text-sm font-medium text-green-600">{s.amount_confirmed ? `$${s.amount_confirmed.toLocaleString()}` : "—"}</TableCell>
                  <TableCell className="text-sm text-muted-foreground">{s.last_contact_date ? format(new Date(s.last_contact_date), "MMM d") : "—"}</TableCell>
                  <TableCell><Badge variant="outline" className="text-xs">{s.priority || "Medium"}</Badge></TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      <Button variant="ghost" size="icon" onClick={() => { setEditing(s); setShowForm(true); }}>
                        <Pencil className="w-3.5 h-3.5" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => deleteMut.mutate(s.id)}>
                        <Trash2 className="w-3.5 h-3.5 text-destructive" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
              {filtered.length === 0 && (
                <TableRow><TableCell colSpan={10} className="text-center py-8 text-muted-foreground">No sponsors tracked yet.</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    </AdminGuard>
  );
}