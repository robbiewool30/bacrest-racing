import React, { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import AdminGuard from "@/components/admin/AdminGuard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2, Save } from "lucide-react";

const emptyGoal = { title: "", description: "", timeframe: "Short Term", status: "Planned", target_date: "", order: 0 };

const CAMPAIGN_KEY = "campaign_page";

const defaultCampaignContent = {
  eyebrow: "2027 Season",
  title: "The Campaign",
  subtitle: "A four-event international programme. Built to compete. Built to win.",
  stat1_value: "4", stat1_label: "Events",
  stat2_value: "2026–27", stat2_label: "Season",
  stat3_value: "World Tour", stat3_label: "Circuit",
  stat4_value: "New Zealand", stat4_label: "Base",
  short_term_label: "Immediate Objectives",
  long_term_label: "Long-Term Vision",
};

async function fetchOrInitContent(key, defaults) {
  const list = await base44.entities.SiteContent.filter({ key });
  if (list && list.length > 0) return list[0];
  return { key, extra: defaults };
}

function GoalRow({ goal, onChange, onDelete }) {
  return (
    <div className="border border-white/8 bg-white/[0.02] p-4 space-y-3">
      <div className="grid sm:grid-cols-2 gap-3">
        <div>
          <Label className="text-white/50 text-xs">Title</Label>
          <Input value={goal.title} onChange={(e) => onChange({ ...goal, title: e.target.value })} placeholder="Goal title" />
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div>
            <Label className="text-white/50 text-xs">Timeframe</Label>
            <Select value={goal.timeframe} onValueChange={(v) => onChange({ ...goal, timeframe: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="Short Term">Short Term</SelectItem>
                <SelectItem value="Long Term">Long Term</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-white/50 text-xs">Status</Label>
            <Select value={goal.status} onValueChange={(v) => onChange({ ...goal, status: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="Planned">Planned</SelectItem>
                <SelectItem value="In Progress">In Progress</SelectItem>
                <SelectItem value="Achieved">Achieved</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>
      <div className="grid sm:grid-cols-2 gap-3">
        <div>
          <Label className="text-white/50 text-xs">Description</Label>
          <Textarea value={goal.description || ""} onChange={(e) => onChange({ ...goal, description: e.target.value })} rows={2} placeholder="Optional description" />
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div>
            <Label className="text-white/50 text-xs">Target Date</Label>
            <Input type="date" value={goal.target_date || ""} onChange={(e) => onChange({ ...goal, target_date: e.target.value })} />
          </div>
          <div>
            <Label className="text-white/50 text-xs">Order</Label>
            <Input type="number" value={goal.order || 0} onChange={(e) => onChange({ ...goal, order: Number(e.target.value) })} />
          </div>
        </div>
      </div>
      <div className="flex justify-end">
        <Button variant="outline" size="sm" onClick={onDelete} className="text-destructive border-destructive/30 hover:bg-destructive/10">
          <Trash2 className="w-3.5 h-3.5" /> Remove
        </Button>
      </div>
    </div>
  );
}

export default function CampaignEditor() {
  const queryClient = useQueryClient();
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [contentRecord, setContentRecord] = useState(null);
  const [fields, setFields] = useState(defaultCampaignContent);

  const { data: goals = [] } = useQuery({
    queryKey: ["campaign-goals"],
    queryFn: () => base44.entities.CampaignGoal.list("order"),
  });

  const [localGoals, setLocalGoals] = useState(null);
  const activeGoals = localGoals ?? goals;

  useEffect(() => {
    if (goals.length > 0 && localGoals === null) setLocalGoals(goals);
  }, [goals]);

  useEffect(() => {
    fetchOrInitContent(CAMPAIGN_KEY, defaultCampaignContent).then((rec) => {
      setContentRecord(rec);
      setFields({ ...defaultCampaignContent, ...(rec?.extra || {}) });
    });
  }, []);

  const setField = (k, v) => setFields((f) => ({ ...f, [k]: v }));

  const updateGoal = (index, updated) => {
    setLocalGoals((prev) => prev.map((g, i) => (i === index ? updated : g)));
  };

  const addGoal = () => {
    setLocalGoals((prev) => [...(prev || []), { ...emptyGoal, _isNew: true, _tempId: Date.now() }]);
  };

  const removeGoal = async (index) => {
    const goal = activeGoals[index];
    if (goal.id) {
      await base44.entities.CampaignGoal.delete(goal.id);
      queryClient.invalidateQueries({ queryKey: ["campaign-goals"] });
    }
    setLocalGoals((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSave = async () => {
    setSaving(true);
    // Save page content
    if (contentRecord?.id) {
      await base44.entities.SiteContent.update(contentRecord.id, { key: CAMPAIGN_KEY, extra: fields });
    } else {
      const created = await base44.entities.SiteContent.create({ key: CAMPAIGN_KEY, extra: fields });
      setContentRecord(created);
    }
    // Save goals
    for (const goal of activeGoals) {
      const { _isNew, _tempId, ...data } = goal;
      if (goal.id) {
        await base44.entities.CampaignGoal.update(goal.id, data);
      } else {
        await base44.entities.CampaignGoal.create(data);
      }
    }
    queryClient.invalidateQueries({ queryKey: ["campaign-goals"] });
    queryClient.invalidateQueries({ queryKey: ["campaign-content"] });
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const Field = ({ label, k, textarea }) => (
    <div>
      <Label className="text-white/50 text-xs">{label}</Label>
      {textarea
        ? <Textarea value={fields[k] || ""} onChange={(e) => setField(k, e.target.value)} rows={2} />
        : <Input value={fields[k] || ""} onChange={(e) => setField(k, e.target.value)} />}
    </div>
  );

  return (
    <AdminGuard>
      <div className="max-w-4xl mx-auto px-6 py-16">
        <div className="mb-10">
          <p className="text-xs font-600 tracking-[0.2em] uppercase text-crimson mb-2">Admin</p>
          <h1 className="font-display text-4xl font-800 uppercase tracking-wide text-white leading-none">Campaign Editor</h1>
          <div className="mt-4 w-12 h-px bg-crimson" />
        </div>

        {/* Page hero content */}
        <div className="mb-10">
          <div className="flex items-center gap-4 mb-5">
            <div className="w-2 h-2 bg-crimson" />
            <p className="text-xs font-700 tracking-[0.2em] uppercase text-white/40">Page Header</p>
            <div className="flex-1 h-px bg-white/5" />
          </div>
          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="Eyebrow text" k="eyebrow" />
            <Field label="Page title" k="title" />
            <Field label="Subtitle / tagline" k="subtitle" textarea />
          </div>
        </div>

        {/* Stats strip */}
        <div className="mb-10">
          <div className="flex items-center gap-4 mb-5">
            <div className="w-2 h-2 bg-white/20" />
            <p className="text-xs font-700 tracking-[0.2em] uppercase text-white/40">Stats Strip (4 columns)</p>
            <div className="flex-1 h-px bg-white/5" />
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[1,2,3,4].map((n) => (
              <div key={n} className="space-y-2">
                <div>
                  <Label className="text-white/50 text-xs">Value {n}</Label>
                  <Input value={fields[`stat${n}_value`] || ""} onChange={(e) => setField(`stat${n}_value`, e.target.value)} />
                </div>
                <div>
                  <Label className="text-white/50 text-xs">Label {n}</Label>
                  <Input value={fields[`stat${n}_label`] || ""} onChange={(e) => setField(`stat${n}_label`, e.target.value)} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Section labels */}
        <div className="mb-10">
          <div className="flex items-center gap-4 mb-5">
            <div className="w-2 h-2 bg-white/20" />
            <p className="text-xs font-700 tracking-[0.2em] uppercase text-white/40">Section Labels</p>
            <div className="flex-1 h-px bg-white/5" />
          </div>
          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="Short Term section label" k="short_term_label" />
            <Field label="Long Term section label" k="long_term_label" />
          </div>
        </div>

        {/* Goals */}
        <div className="mb-6">
          <div className="flex items-center gap-4 mb-5">
            <div className="w-2 h-2 bg-crimson" />
            <p className="text-xs font-700 tracking-[0.2em] uppercase text-white/40">Goals & Objectives</p>
            <div className="flex-1 h-px bg-white/5" />
          </div>
          <div className="space-y-3">
            {activeGoals.map((goal, i) => (
              <GoalRow
                key={goal.id || goal._tempId || i}
                goal={goal}
                onChange={(updated) => updateGoal(i, updated)}
                onDelete={() => removeGoal(i)}
              />
            ))}
          </div>
        </div>

        <div className="flex items-center gap-3">
          <Button variant="outline" onClick={addGoal}>
            <Plus className="w-4 h-4" /> Add Goal
          </Button>
          <Button onClick={handleSave} disabled={saving} className="bg-crimson hover:bg-crimson/90 text-white border-0">
            <Save className="w-4 h-4" /> {saving ? "Saving..." : saved ? "Saved!" : "Save All"}
          </Button>
        </div>
      </div>
    </AdminGuard>
  );
}