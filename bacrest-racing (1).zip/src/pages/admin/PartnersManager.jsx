import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import AdminGuard from "@/components/admin/AdminGuard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Building2, Plus, Pencil, Trash2, X, Save } from "lucide-react";

const TIERS = ["Platinum", "Gold", "Silver", "Official Partner", "Preferred"];
const empty = { name: "", tier: "Silver", logo_url: "", website_url: "", description: "", order: 0 };

function PartnerForm({ initial, onSave, onCancel }) {
  const [form, setForm] = useState({ ...empty, ...initial });
  const [saving, setSaving] = useState(false);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const handleSave = async () => {
    setSaving(true);
    const data = { ...form, order: form.order ? Number(form.order) : 0 };
    if (initial?.id) await base44.entities.Partner.update(initial.id, data);
    else await base44.entities.Partner.create(data);
    setSaving(false);
    onSave();
  };

  return (
    <div className="bg-card border rounded-xl p-5 mb-4">
      <div className="flex items-center justify-between mb-4">
        <h4 className="font-semibold">{initial?.id ? "Edit Partner" : "Add Partner"}</h4>
        <button onClick={onCancel}><X className="w-4 h-4 text-muted-foreground" /></button>
      </div>
      <div className="grid sm:grid-cols-2 gap-3">
        <div><Label>Partner Name *</Label><Input value={form.name} onChange={(e) => set("name", e.target.value)} /></div>
        <div>
          <Label>Tier</Label>
          <Select value={form.tier} onValueChange={(v) => set("tier", v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{TIERS.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div><Label>Logo URL</Label><Input value={form.logo_url} onChange={(e) => set("logo_url", e.target.value)} placeholder="https://..." /></div>
        <div><Label>Website URL</Label><Input value={form.website_url} onChange={(e) => set("website_url", e.target.value)} placeholder="https://..." /></div>
        <div><Label>Display Order</Label><Input type="number" value={form.order} onChange={(e) => set("order", e.target.value)} /></div>
        <div className="sm:col-span-2"><Label>Description</Label><Textarea value={form.description} onChange={(e) => set("description", e.target.value)} rows={2} /></div>
      </div>
      <div className="flex gap-2 mt-4">
        <Button onClick={handleSave} disabled={saving || !form.name}><Save className="w-4 h-4" />{saving ? "Saving..." : "Save"}</Button>
        <Button variant="outline" onClick={onCancel}>Cancel</Button>
      </div>
    </div>
  );
}

export default function PartnersManager() {
  const queryClient = useQueryClient();
  const [editing, setEditing] = useState(null);
  const [confirmDelete, setConfirmDelete] = useState(null);

  const { data: partners = [] } = useQuery({ queryKey: ["partners"], queryFn: () => base44.entities.Partner.list("order") });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Partner.delete(id),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["partners"] }); setConfirmDelete(null); },
  });

  const handleSaved = () => { queryClient.invalidateQueries({ queryKey: ["partners"] }); setEditing(null); };

  return (
    <AdminGuard>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-12">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="font-display text-3xl font-bold">Partners Manager</h1>
            <p className="text-muted-foreground mt-1">{partners.length} partner{partners.length !== 1 ? "s" : ""}</p>
          </div>
          {!editing && (
            <Button onClick={() => setEditing({})}><Plus className="w-4 h-4" /> Add Partner</Button>
          )}
        </div>

        {editing && <PartnerForm initial={editing} onSave={handleSaved} onCancel={() => setEditing(null)} />}

        {partners.length === 0 && !editing ? (
          <div className="text-center py-16 bg-card border rounded-xl">
            <Building2 className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground">No partners added yet.</p>
          </div>
        ) : (
          <div className="space-y-2">
            {partners.map((p) => (
              <div key={p.id} className="bg-card border rounded-xl px-4 py-3 flex items-center gap-4">
                {p.logo_url ? (
                  <img src={p.logo_url} alt={p.name} className="w-12 h-12 object-contain flex-shrink-0" />
                ) : (
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Building2 className="w-5 h-5 text-primary/40" />
                  </div>
                )}
                <div className="flex-1">
                  <p className="font-semibold">{p.name}</p>
                  <p className="text-xs text-muted-foreground">{p.tier}{p.website_url ? ` · ${p.website_url}` : ""}</p>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="icon" onClick={() => setEditing(p)}><Pencil className="w-4 h-4" /></Button>
                  {confirmDelete === p.id ? (
                    <><Button variant="destructive" size="sm" onClick={() => deleteMutation.mutate(p.id)}>Delete</Button><Button variant="outline" size="sm" onClick={() => setConfirmDelete(null)}>Cancel</Button></>
                  ) : (
                    <Button variant="outline" size="icon" onClick={() => setConfirmDelete(p.id)}><Trash2 className="w-4 h-4 text-destructive" /></Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </AdminGuard>
  );
}