import React, { useState, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import AdminGuard from "@/components/admin/AdminGuard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Save } from "lucide-react";

const KEYS = {
  hero: {
    label: "Hero Section",
    fields: [
      { key: "title", label: "Hero Title (use \\n for line breaks)", type: "textarea" },
      { key: "subtitle", label: "Eyebrow text (e.g. New Zealand · Match Racing · 2027)", type: "input" },
      { key: "body", label: "Sub-tagline paragraph", type: "textarea" },
      { key: "image_url", label: "Hero Background Image URL", type: "input" },
    ],
  },
  campaign_brief: {
    label: "Campaign Brief Section",
    fields: [
      { key: "title", label: "Heading", type: "input" },
      { key: "subtitle", label: "Sub-heading", type: "input" },
      { key: "body", label: "Body paragraph", type: "textarea" },
      { key: "image_url", label: "Side Image URL", type: "input" },
    ],
  },
  pillars: {
    label: "Pillars (3 cards)",
    isPillars: true,
  },
  partner_cta: {
    label: "Partnership CTA Section",
    fields: [
      { key: "title", label: "Heading", type: "input" },
      { key: "body", label: "Description paragraph", type: "textarea" },
    ],
  },
};

const DEFAULT_PILLARS = [
  { number: "01", title: "Precision Racing", desc: "Match racing at the highest level demands split-second decision-making and flawless boat-handling under extreme pressure." },
  { number: "02", title: "2027 Campaign", desc: "Four international World Tour events. November 2026 through October 2027. New Zealand to the world." },
  { number: "03", title: "Systems Approach", desc: "Every element of the campaign — technical, physical, tactical — engineered and optimised as an integrated system." },
];

async function getOrCreate(key) {
  const list = await base44.entities.SiteContent.filter({ key });
  if (list.length > 0) return list[0];
  return await base44.entities.SiteContent.create({ key });
}

export default function HomeEditor() {
  const queryClient = useQueryClient();
  const [data, setData] = useState({});
  const [pillars, setPillars] = useState(DEFAULT_PILLARS);
  const [records, setRecords] = useState({});
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    (async () => {
      const loaded = {};
      const rec = {};
      for (const sectionKey of Object.keys(KEYS)) {
        const r = await getOrCreate(`home_${sectionKey}`);
        rec[sectionKey] = r;
        loaded[sectionKey] = { title: r.title || "", subtitle: r.subtitle || "", body: r.body || "", image_url: r.image_url || "" };
        if (sectionKey === "pillars" && r.extra?.pillars) {
          setPillars(r.extra.pillars);
        }
      }
      setData(loaded);
      setRecords(rec);
    })();
  }, []);

  const set = (section, field, value) => {
    setData((prev) => ({ ...prev, [section]: { ...prev[section], [field]: value } }));
  };

  const setPillar = (i, field, value) => {
    setPillars((prev) => prev.map((p, idx) => idx === i ? { ...p, [field]: value } : p));
  };

  const handleSave = async () => {
    setSaving(true);
    for (const sectionKey of Object.keys(KEYS)) {
      const r = records[sectionKey];
      if (!r) continue;
      const updates = { ...data[sectionKey] };
      if (sectionKey === "pillars") {
        updates.extra = { pillars };
      }
      await base44.entities.SiteContent.update(r.id, updates);
    }
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <AdminGuard>
      <div className="max-w-3xl mx-auto px-6 py-16">
        <div className="mb-10">
          <p className="text-xs font-600 tracking-[0.2em] uppercase text-crimson mb-2">Admin</p>
          <h1 className="font-display text-4xl font-800 uppercase tracking-wide text-white leading-none">Home Page Editor</h1>
          <div className="mt-4 w-12 h-px bg-crimson" />
        </div>

        <div className="space-y-10">
          {Object.entries(KEYS).map(([sectionKey, config]) => (
            <div key={sectionKey} className="border border-white/8 p-6">
              <div className="flex items-center gap-3 mb-5">
                <div className="w-1.5 h-1.5 bg-crimson" />
                <p className="text-xs font-700 tracking-[0.2em] uppercase text-white/50">{config.label}</p>
              </div>

              {config.isPillars ? (
                <div className="space-y-4">
                  {pillars.map((p, i) => (
                    <div key={i} className="border border-white/5 p-4 space-y-2">
                      <p className="text-xs text-white/30 tracking-wider uppercase mb-2">Pillar {p.number}</p>
                      <div>
                        <Label className="text-white/40 text-xs">Title</Label>
                        <Input value={p.title} onChange={(e) => setPillar(i, "title", e.target.value)} />
                      </div>
                      <div>
                        <Label className="text-white/40 text-xs">Description</Label>
                        <Textarea value={p.desc} onChange={(e) => setPillar(i, "desc", e.target.value)} rows={2} />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="space-y-4">
                  {config.fields.map(({ key, label, type }) => (
                    <div key={key}>
                      <Label className="text-white/40 text-xs mb-1 block">{label}</Label>
                      {type === "textarea" ? (
                        <Textarea
                          value={data[sectionKey]?.[key] || ""}
                          onChange={(e) => set(sectionKey, key, e.target.value)}
                          rows={3}
                          placeholder={`Enter ${label.toLowerCase()}...`}
                        />
                      ) : (
                        <Input
                          value={data[sectionKey]?.[key] || ""}
                          onChange={(e) => set(sectionKey, key, e.target.value)}
                          placeholder={`Enter ${label.toLowerCase()}...`}
                        />
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="mt-8">
          <p className="text-xs text-white/20 mb-4 tracking-wide">
            Note: Changes here update the database. The Home page will use these values if set, otherwise falls back to the default text.
          </p>
          <Button onClick={handleSave} disabled={saving} className="bg-crimson hover:bg-crimson/90 text-white border-0">
            <Save className="w-4 h-4" /> {saving ? "Saving..." : saved ? "Saved!" : "Save Changes"}
          </Button>
        </div>
      </div>
    </AdminGuard>
  );
}