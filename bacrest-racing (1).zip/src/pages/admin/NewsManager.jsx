import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import AdminGuard from "@/components/admin/AdminGuard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Pencil, Trash2, X, Save, Upload, EyeOff } from "lucide-react";
import { format } from "date-fns";

const empty = { title: "", date: new Date().toISOString().slice(0, 10), cover_photo_url: "", body: "", album_link: "", tags: [], published: true };

function PostForm({ initial, onSave, onCancel, albums }) {
  const [form, setForm] = useState({ ...empty, ...initial, tags: initial?.tags || [] });
  const [tagInput, setTagInput] = useState("");
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const uploadCover = async (file) => {
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setUploading(false);
    set("cover_photo_url", file_url);
  };

  const addTag = () => {
    const t = tagInput.trim();
    if (t && !form.tags.includes(t)) set("tags", [...form.tags, t]);
    setTagInput("");
  };

  const removeTag = (tag) => set("tags", form.tags.filter((t) => t !== tag));

  const handleSave = async () => {
    if (!form.title) return;
    setSaving(true);
    if (initial?.id) {
      await base44.entities.NewsPost.update(initial.id, form);
    } else {
      await base44.entities.NewsPost.create(form);
    }
    setSaving(false);
    onSave();
  };

  return (
    <div className="border border-white/8 bg-white/[0.02] p-6 mb-8">
      <div className="flex items-center justify-between mb-6">
        <h3 className="font-display text-lg font-700 uppercase text-white/80">{initial?.id ? "Edit Post" : "New Post"}</h3>
        <button onClick={onCancel}><X className="w-5 h-5 text-white/30 hover:text-white/60" /></button>
      </div>

      <div className="space-y-5">
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <Label className="text-white/50 text-xs">Title *</Label>
            <Input value={form.title} onChange={(e) => set("title", e.target.value)} placeholder="Event Report: World Cup 2026" />
          </div>
          <div>
            <Label className="text-white/50 text-xs">Date *</Label>
            <Input type="date" value={form.date} onChange={(e) => set("date", e.target.value)} />
          </div>
        </div>

        {/* Cover photo */}
        <div>
          <Label className="text-white/50 text-xs">Cover Photo</Label>
          <label className="mt-1 flex flex-col items-center justify-center gap-2 cursor-pointer border border-dashed border-white/20 bg-white/[0.02] hover:bg-white/[0.05] px-4 py-5 transition-colors text-center"
            onDrop={(e) => { e.preventDefault(); const f = e.dataTransfer.files[0]; if (f) uploadCover(f); }}
            onDragOver={(e) => e.preventDefault()}
          >
            <Upload className="w-5 h-5 text-white/30" />
            <span className="text-sm text-white/40">{uploading ? "Uploading…" : form.cover_photo_url ? "Replace — click or drag" : "Click or drag cover photo"}</span>
            <input type="file" accept="image/*" className="hidden" onChange={(e) => { if (e.target.files[0]) uploadCover(e.target.files[0]); }} />
          </label>
          {form.cover_photo_url && !uploading && (
            <img src={form.cover_photo_url} alt="cover" className="mt-2 h-28 object-cover" />
          )}
        </div>

        {/* Body */}
        <div>
          <Label className="text-white/50 text-xs mb-1 block">Body</Label>
          <Textarea
            value={form.body}
            onChange={(e) => set("body", e.target.value)}
            placeholder="Write your post content here..."
            className="min-h-[200px] bg-white/[0.02] text-white/80 resize-y"
          />
        </div>

        {/* Album link */}
        <div>
          <Label className="text-white/50 text-xs">Linked Album (optional)</Label>
          <Select value={form.album_link || "__none__"} onValueChange={(v) => set("album_link", v === "__none__" ? "" : v)}>
            <SelectTrigger className="mt-1">
              <SelectValue placeholder="Select an album…" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="__none__">— None —</SelectItem>
              {albums.map((album) => (
                <SelectItem key={album} value={album}>{album}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Tags */}
        <div>
          <Label className="text-white/50 text-xs">Tags / Categories</Label>
          <div className="flex gap-2 mt-1">
            <Input
              value={tagInput}
              onChange={(e) => setTagInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addTag(); } }}
              placeholder="e.g. Match Racing, Event Report"
            />
            <Button variant="outline" onClick={addTag} type="button">Add</Button>
          </div>
          {form.tags.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-2">
              {form.tags.map((tag) => (
                <span key={tag} className="flex items-center gap-1 text-xs px-2 py-1 border border-white/10 text-white/50">
                  {tag}
                  <button onClick={() => removeTag(tag)}><X className="w-3 h-3 hover:text-white/80" /></button>
                </span>
              ))}
            </div>
          )}
        </div>

        {/* Published toggle */}
        <div className="flex items-center gap-3">
          <Switch checked={form.published} onCheckedChange={(v) => set("published", v)} />
          <Label className="text-white/50 text-xs">{form.published ? "Published (visible publicly)" : "Draft (hidden from public)"}</Label>
        </div>
      </div>

      <div className="flex gap-2 mt-6">
        <Button onClick={handleSave} disabled={saving || uploading || !form.title} className="bg-crimson hover:bg-crimson/90 text-white border-0">
          <Save className="w-4 h-4" /> {saving ? "Saving..." : "Save Post"}
        </Button>
        <Button variant="outline" onClick={onCancel}>Cancel</Button>
      </div>
    </div>
  );
}

export default function NewsManager() {
  const queryClient = useQueryClient();
  const [editing, setEditing] = useState(null);
  const [confirmDelete, setConfirmDelete] = useState(null);

  const { data: posts = [] } = useQuery({
    queryKey: ["news-admin"],
    queryFn: () => base44.entities.NewsPost.list("-date"),
  });

  const { data: mediaItems = [] } = useQuery({
    queryKey: ["media-albums"],
    queryFn: () => base44.entities.MediaItem.list("order"),
  });

  const albums = [...new Set(mediaItems.map((m) => m.album).filter(Boolean))];

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.NewsPost.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["news-admin"] });
      queryClient.invalidateQueries({ queryKey: ["news"] });
      setConfirmDelete(null);
    },
  });

  const handleSaved = () => {
    queryClient.invalidateQueries({ queryKey: ["news-admin"] });
    queryClient.invalidateQueries({ queryKey: ["news"] });
    setEditing(null);
  };

  return (
    <AdminGuard>
      <div className="max-w-4xl mx-auto px-6 py-16">
        <div className="mb-10">
          <p className="text-xs font-600 tracking-[0.2em] uppercase text-crimson mb-2">Admin</p>
          <h1 className="font-display text-4xl font-800 uppercase tracking-wide text-white leading-none">News Manager</h1>
          <div className="mt-4 w-12 h-px bg-crimson" />
        </div>

        {editing !== null && (
          <PostForm initial={editing} onSave={handleSaved} onCancel={() => setEditing(null)} albums={albums} />
        )}

        {editing === null && (
          <Button onClick={() => setEditing({})} className="mb-8 bg-crimson hover:bg-crimson/90 text-white border-0">
            <Plus className="w-4 h-4" /> New Post
          </Button>
        )}

        {posts.length === 0 ? (
          <div className="text-center py-16 border border-white/5">
            <p className="text-white/25 text-sm">No posts yet. Create the first one above.</p>
          </div>
        ) : (
          <div className="space-y-px">
            {posts.map((post) => (
              <div key={post.id} className="border border-white/5 bg-white/[0.01] p-4 flex items-center gap-4 hover:bg-white/[0.03] transition-colors">
                {post.cover_photo_url && (
                  <img src={post.cover_photo_url} alt="" className="w-16 h-11 object-cover flex-shrink-0" />
                )}
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-white/80 truncate">{post.title}</p>
                  <div className="flex items-center gap-3 mt-0.5">
                    <p className="text-xs text-white/30">{post.date ? format(new Date(post.date), "dd MMM yyyy") : ""}</p>
                    {!post.published && (
                      <span className="flex items-center gap-1 text-[10px] text-white/30 border border-white/10 px-1.5 py-0.5 uppercase tracking-wide">
                        <EyeOff className="w-3 h-3" /> Draft
                      </span>
                    )}
                    {(post.tags || []).slice(0, 3).map((t) => (
                      <span key={t} className="text-[10px] text-white/25 border border-white/8 px-1.5 py-0.5 uppercase tracking-wide">{t}</span>
                    ))}
                  </div>
                </div>
                <div className="flex gap-2 flex-shrink-0">
                  <Button variant="outline" size="icon" onClick={() => setEditing(post)}>
                    <Pencil className="w-4 h-4" />
                  </Button>
                  {confirmDelete === post.id ? (
                    <div className="flex gap-1">
                      <Button variant="destructive" size="sm" onClick={() => deleteMutation.mutate(post.id)}>Delete</Button>
                      <Button variant="outline" size="sm" onClick={() => setConfirmDelete(null)}>Cancel</Button>
                    </div>
                  ) : (
                    <Button variant="outline" size="icon" onClick={() => setConfirmDelete(post.id)}>
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </AdminGuard>
  );
}