import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Link, useParams } from "react-router-dom";
import { format } from "date-fns";
import { CalendarDays, ArrowLeft, Images, X } from "lucide-react";

export default function NewsPostPage() {
  const { id } = useParams();
  const [lightbox, setLightbox] = useState(null);

  const { data: posts = [], isLoading } = useQuery({
    queryKey: ["news"],
    queryFn: () => base44.entities.NewsPost.list("-date"),
  });

  const { data: allMedia = [] } = useQuery({
    queryKey: ["media"],
    queryFn: () => base44.entities.MediaItem.list("order"),
  });

  const post = posts.find((p) => p.id === id);

  const albumPhotos = post?.album_link
    ? allMedia.filter((m) => m.album === post.album_link && m.type === "image")
    : [];

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-32">
        <div className="w-8 h-8 border-4 border-muted border-t-crimson rounded-full animate-spin" />
      </div>
    );
  }

  if (!post) {
    return (
      <div className="text-center py-32">
        <p className="text-white/30 text-sm">Post not found.</p>
        <Link to="/news" className="text-crimson text-sm mt-4 inline-block">← Back to News</Link>
      </div>
    );
  }

  return (
    <div className="bg-background min-h-screen">
      {/* Back nav */}
      <div className="max-w-3xl mx-auto px-6 pt-24 pb-4">
        <Link to="/news" className="inline-flex items-center gap-2 text-xs text-white/30 hover:text-white/60 tracking-[0.15em] uppercase transition-colors">
          <ArrowLeft className="w-3.5 h-3.5" /> Back to News
        </Link>
      </div>

      {/* Cover photo */}
      <div className="max-w-3xl mx-auto px-6 mb-8">
        <img
          src={post.cover_photo_url || "https://media.base44.com/images/public/69fc1bba3da642f89dcfa939/1599bb6ac_BacrestRacingNewsImage.png"}
          alt={post.title}
          className="w-full max-h-[420px] object-cover"
        />
      </div>

      <article className="max-w-3xl mx-auto px-6 pb-24">
        {/* Meta */}
        <div className="flex flex-wrap items-center gap-4 mb-4">
          {post.date && (
            <span className="flex items-center gap-1.5 text-xs text-crimson tracking-[0.15em] uppercase">
              <CalendarDays className="w-3.5 h-3.5" />
              {format(new Date(post.date), "dd MMMM yyyy")}
            </span>
          )}
          {(post.tags || []).map((tag) => (
            <span key={tag} className="text-[10px] px-2 py-0.5 border border-white/10 text-white/30 tracking-wide uppercase">
              {tag}
            </span>
          ))}
        </div>

        <h1 className="font-display text-4xl sm:text-5xl font-800 uppercase tracking-wide text-white leading-none mb-6">
          {post.title}
        </h1>
        <div className="w-12 h-px bg-crimson mb-8" />

        {/* Body */}
        {post.body && (
          <div
            className="prose prose-invert prose-sm max-w-none text-white/70 leading-relaxed [&_p]:min-h-[1em] [&_p:empty]:min-h-[1em] [&_br]:block"
            dangerouslySetInnerHTML={{ __html: post.body }}
          />
        )}

        {/* Album photos */}
        {albumPhotos.length > 0 && (
          <div className="mt-10 pt-8 border-t border-white/5">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-display text-xl font-700 uppercase tracking-wide text-white/80">Event Photos</h2>
              <Link
                to={`/media?album=${encodeURIComponent(post.album_link)}`}
                className="inline-flex items-center gap-1.5 text-xs text-crimson hover:text-crimson/80 tracking-wide uppercase transition-colors"
              >
                <Images className="w-3.5 h-3.5" /> View Full Album →
              </Link>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {albumPhotos.map((photo) => (
                <div
                  key={photo.id}
                  className="aspect-video overflow-hidden cursor-pointer group"
                  onClick={() => setLightbox(photo.url)}
                >
                  <img
                    src={photo.url}
                    alt={photo.title || ""}
                    className="w-full h-full object-cover transition-transform group-hover:scale-105"
                  />
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Album link only (no photos fetched) */}
        {post.album_link && albumPhotos.length === 0 && (
          <div className="mt-10 pt-8 border-t border-white/5">
            <Link
              to={`/media?album=${encodeURIComponent(post.album_link)}`}
              className="inline-flex items-center gap-2 text-sm text-crimson hover:text-crimson/80 tracking-wide transition-colors"
            >
              <Images className="w-4 h-4" /> View Event Album →
            </Link>
          </div>
        )}
      </article>

      {/* Lightbox */}
      {lightbox && (
        <div
          className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4"
          onClick={() => setLightbox(null)}
        >
          <button className="absolute top-4 right-4 text-white" onClick={() => setLightbox(null)}>
            <X className="w-6 h-6" />
          </button>
          <img src={lightbox} alt="" className="max-w-full max-h-[85vh] rounded-lg" />
        </div>
      )}
    </div>
  );
}