import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import PageHero from "@/components/shared/PageHero";
import { format } from "date-fns";
import { CalendarDays, Tag, Images } from "lucide-react";
import { motion } from "framer-motion";

export default function News() {
  const [activeTag, setActiveTag] = useState("All");

  const { data: posts = [] } = useQuery({
    queryKey: ["news"],
    queryFn: () => base44.entities.NewsPost.filter({ published: true }, "-date"),
  });

  // Collect all tags
  const allTags = ["All", ...Array.from(new Set(posts.flatMap((p) => p.tags || [])))];

  const filtered = activeTag === "All" ? posts : posts.filter((p) => (p.tags || []).includes(activeTag));

  return (
    <div className="bg-background">
      <PageHero eyebrow="Latest" title="News" subtitle="Event reports, campaign updates and behind-the-scenes." />

      <section className="py-16 max-w-6xl mx-auto px-6">
        {/* Tag filter */}
        {allTags.length > 1 && (
          <div className="flex flex-wrap gap-2 mb-10">
            {allTags.map((tag) => (
              <button
                key={tag}
                onClick={() => setActiveTag(tag)}
                className={`px-3 py-1 text-xs font-600 tracking-[0.12em] uppercase border transition-colors ${
                  activeTag === tag
                    ? "border-crimson bg-crimson/10 text-crimson"
                    : "border-white/10 text-white/40 hover:border-white/30 hover:text-white/60"
                }`}
              >
                {tag}
              </button>
            ))}
          </div>
        )}

        {filtered.length === 0 ? (
          <p className="text-center text-white/25 text-sm tracking-[0.2em] uppercase py-16">No posts yet.</p>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map((post, i) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
              >
                <Link to={`/news/${post.id}`} className="group block border border-white/5 hover:border-white/10 bg-card transition-colors overflow-hidden">
                  <div className="aspect-video overflow-hidden">
                    <img
                      src={post.cover_photo_url || "https://media.base44.com/images/public/69fc1bba3da642f89dcfa939/1599bb6ac_BacrestRacingNewsImage.png"}
                      alt={post.title}
                      className="w-full h-full object-cover transition-transform group-hover:scale-105"
                    />
                  </div>
                  <div className="p-5">
                    <p className="text-xs text-crimson tracking-[0.15em] uppercase mb-2">
                      {post.date ? format(new Date(post.date), "dd MMM yyyy") : ""}
                    </p>
                    <h2 className="font-display text-lg font-700 uppercase tracking-wide text-white group-hover:text-crimson transition-colors leading-tight mb-3">
                      {post.title}
                    </h2>
                    {(post.tags || []).length > 0 && (
                      <div className="flex flex-wrap gap-1">
                        {post.tags.map((tag) => (
                          <span key={tag} className="text-[10px] px-2 py-0.5 border border-white/10 text-white/30 tracking-wide uppercase">
                            {tag}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}