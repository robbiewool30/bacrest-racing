import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import PageHero from "@/components/shared/PageHero";
import { MapPin, Globe } from "lucide-react";
import { format } from "date-fns";

export default function Results() {
  const { data: results = [] } = useQuery({
    queryKey: ["results"],
    queryFn: () => base44.entities.Result.list("-date"),
  });
  const { data: rankings = [] } = useQuery({
    queryKey: ["rankings"],
    queryFn: () => base44.entities.WorldRanking.list("order"),
  });

  return (
    <div className="bg-background">
      <PageHero
        eyebrow="Performance"
        title="Results"
        subtitle="Competitive record and current world rankings."
      />

      <section className="py-20 max-w-5xl mx-auto px-6 space-y-16">

        {/* World Rankings */}
        {rankings.length > 0 && (
          <div>
            <div className="flex items-center gap-4 mb-8">
              <Globe className="w-4 h-4 text-crimson" />
              <p className="text-xs font-700 tracking-[0.2em] uppercase text-white/50">World Sailing Rankings</p>
              <div className="flex-1 h-px bg-white/5" />
            </div>
            <div className="grid sm:grid-cols-2 gap-px bg-white/5">
              {["Youth", "Open"].map((type) => {
                const r = rankings.find((x) => x.ranking_type === type);
                if (!r) return null;
                return (
                  <div key={type} className="bg-background p-10 text-center">
                    <p className="text-xs font-600 tracking-[0.2em] uppercase text-crimson mb-4">{type} Ranking</p>
                    <p className="font-display text-[5rem] font-900 text-white leading-none">
                      #{r.rank}
                    </p>
                    <p className="text-xs text-white/25 mt-2 tracking-wider uppercase">in the World</p>
                    {r.as_of_date && (
                      <p className="text-xs text-white/20 mt-1">
                        Updated {format(new Date(r.as_of_date), "MMMM d, yyyy")}
                      </p>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Race Results */}
        {["Match Racing", "Fleet Racing"].map((type) => {
          const typeResults = results.filter((r) => r.racing_type === type || (!r.racing_type && type === "Match Racing"));
          if (typeResults.length === 0) return null;
          return (
            <div key={type}>
              <div className="flex items-center gap-4 mb-8">
                <div className="w-2 h-2 bg-crimson" />
                <p className="text-xs font-700 tracking-[0.2em] uppercase text-white/50">{type}</p>
                <div className="flex-1 h-px bg-white/5" />
              </div>
              <div className="border border-white/5 overflow-hidden">
                {/* Header */}
                <div className="grid grid-cols-[1fr_auto_auto_auto] gap-4 px-6 py-3 border-b border-white/5 bg-card">
                  {["Event", "Location", "Date", "Result"].map((h) => (
                    <p key={h} className="text-xs font-600 tracking-[0.15em] uppercase text-white/25">{h}</p>
                  ))}
                </div>
                {/* Rows */}
                {typeResults.map((r, i) => (
                  <div
                    key={r.id}
                    className={`grid grid-cols-[1fr_auto_auto_auto] gap-4 px-6 py-4 items-center border-b border-white/5 last:border-0 hover:bg-card transition-colors ${i % 2 === 0 ? "" : "bg-white/[0.01]"}`}
                  >
                    <p className="font-display text-base font-600 uppercase text-white/90 tracking-wide">{r.event_name}</p>
                    <p className="text-xs text-white/30 flex items-center gap-1 tracking-wide">
                      <MapPin className="w-3 h-3" /> {r.location || "—"}
                    </p>
                    <p className="text-xs text-white/25 tracking-wide">
                      {r.date ? format(new Date(r.date), "dd MMM yyyy") : "—"}
                    </p>
                    <div className="text-right">
                      <span className="font-display text-lg font-800 text-crimson tracking-wide">{r.placement || "—"}</span>
                      {r.fleet_size && (
                        <span className="text-xs text-white/20 ml-1">/{r.fleet_size}</span>
                      )}
                    </div>
                    {r.notes && (
                      <p className="col-span-4 text-xs text-white/40 italic pb-1 -mt-1">{r.notes}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          );
        })}
        {results.length === 0 && (
          <div className="border border-white/5 p-12 text-center">
            <p className="text-xs text-white/20 tracking-[0.2em] uppercase">Results will be posted as we compete.</p>
          </div>
        )}
      </section>
    </div>
  );
}