import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import PageHero from "@/components/shared/PageHero";
import { ExternalLink, Building2, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";

const tierOrder = ["Platinum", "Gold", "Silver", "Official Partner", "Preferred"];

const tierConfig = {
  Platinum: { size: "h-14", grid: "grid-cols-1 sm:grid-cols-2" },
  Gold: { size: "h-10", grid: "grid-cols-2 sm:grid-cols-3" },
  Silver: { size: "h-8", grid: "grid-cols-2 sm:grid-cols-4" },
  "Official Partner": { size: "h-8", grid: "grid-cols-2 sm:grid-cols-3 lg:grid-cols-4" },
  Preferred: { size: "h-7", grid: "grid-cols-3 sm:grid-cols-5" },
};

export default function Partners() {
  const { data: partners = [] } = useQuery({
    queryKey: ["partners"],
    queryFn: () => base44.entities.Partner.list("order"),
  });

  const grouped = tierOrder
    .map((tier) => ({ tier, items: partners.filter((p) => p.tier === tier) }))
    .filter((g) => g.items.length > 0);

  return (
    <div className="bg-background">
      <PageHero
        eyebrow="2027 Campaign"
        title="Partners"
        subtitle="The organisations and people who make this campaign possible."
      />

      <section className="py-20 max-w-6xl mx-auto px-6">
        {partners.length === 0 ? (
          <div className="border border-white/5 p-16 text-center">
            <p className="text-xs text-white/20 tracking-[0.2em] uppercase mb-6">Partner announcements coming soon.</p>
            <Link
              to="/sponsorship"
              className="inline-flex items-center gap-2 text-xs font-700 tracking-[0.15em] uppercase text-crimson hover:text-crimson/80 transition-colors group"
            >
              Explore Partnership Opportunities
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
        ) : (
          <div className="space-y-16">
            {grouped.map(({ tier, items }) => {
              const cfg = tierConfig[tier] || { size: "h-8", grid: "grid-cols-3" };
              return (
                <div key={tier}>
                  {/* Section header */}
                  <div className="flex items-center gap-4 mb-8">
                    <div className="w-2 h-2 bg-crimson flex-shrink-0" />
                    <p className="text-xs font-700 tracking-[0.2em] uppercase text-white/40">{tier}</p>
                    <div className="flex-1 h-px bg-white/5" />
                  </div>

                  <div className={`grid ${cfg.grid} gap-px bg-white/5`}>
                    {items.map((p, i) => (
                      <motion.div
                        key={p.id}
                        initial={{ opacity: 0 }}
                        whileInView={{ opacity: 1 }}
                        viewport={{ once: true }}
                        transition={{ delay: i * 0.04 }}
                        className="bg-background group relative"
                      >
                        <div className="p-8 flex flex-col items-center justify-center text-center h-full">
                          {p.logo_url ? (
                            <img
                              src={p.logo_url}
                              alt={p.name}
                              className={`${cfg.size} w-auto mx-auto object-contain filter grayscale group-hover:grayscale-0 opacity-50 group-hover:opacity-100 transition-all duration-300`}
                            />
                          ) : (
                            <div className="flex flex-col items-center gap-3">
                              <Building2 className="w-6 h-6 text-white/15" />
                              <p className="font-display text-sm font-600 uppercase tracking-wide text-white/50 group-hover:text-white/80 transition-colors">{p.name}</p>
                            </div>
                          )}
                          {p.logo_url && (
                            <p className="mt-3 text-xs text-white/20 group-hover:text-white/50 transition-colors font-500 tracking-wide">{p.name}</p>
                          )}
                          {p.website_url && (
                            <a
                              href={p.website_url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="absolute inset-0"
                              aria-label={`Visit ${p.name}`}
                            />
                          )}
                        </div>
                        <div className="absolute bottom-0 left-0 right-0 h-px bg-crimson/0 group-hover:bg-crimson/40 transition-colors" />
                      </motion.div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* CTA */}
      <section className="border-t border-white/5 carbon-bg">
        <div className="max-w-4xl mx-auto px-6 py-16 text-center">
          <p className="text-xs font-600 tracking-[0.2em] uppercase text-crimson mb-4">Partnership Opportunities</p>
          <h3 className="font-display text-3xl font-800 uppercase tracking-wide text-white mb-6">Join the Campaign</h3>
          <Link
            to="/sponsorship"
            className="inline-flex items-center gap-3 bg-crimson text-white px-8 py-3 text-xs font-700 tracking-[0.15em] uppercase hover:bg-crimson/90 transition-colors group"
          >
            View Tiers
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
      </section>
    </div>
  );
}