import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import PageHero from "@/components/shared/PageHero";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Send, CheckCircle2 } from "lucide-react";

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });
  const [sent, setSent] = useState(false);
  const [sending, setSending] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSending(true);
    await base44.entities.ContactMessage.create(form);
    setSent(true);
    setSending(false);
  };

  return (
    <div className="bg-background">
      <PageHero
        eyebrow="Get in Touch"
        title="Contact"
        subtitle="Direct enquiries from potential partners, media, and race officials."
      />

      <section className="py-20 max-w-2xl mx-auto px-6">
        {sent ? (
          <div className="border border-white/5 p-16 text-center">
            <CheckCircle2 className="w-8 h-8 text-crimson mx-auto mb-4" />
            <h3 className="font-display text-2xl font-700 uppercase tracking-wide text-white mb-2">Transmitted</h3>
            <p className="text-xs text-white/30 tracking-wider uppercase">We'll respond promptly.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid sm:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="name" className="text-xs font-600 tracking-[0.15em] uppercase text-white/40 mb-2 block">Name</Label>
                <Input
                  id="name"
                  required
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="Your name"
                  className="bg-card border-white/10 text-white placeholder:text-white/20 focus-visible:ring-crimson/50 rounded-none h-11"
                />
              </div>
              <div>
                <Label htmlFor="email" className="text-xs font-600 tracking-[0.15em] uppercase text-white/40 mb-2 block">Email</Label>
                <Input
                  id="email"
                  type="email"
                  required
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  placeholder="you@example.com"
                  className="bg-card border-white/10 text-white placeholder:text-white/20 focus-visible:ring-crimson/50 rounded-none h-11"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="subject" className="text-xs font-600 tracking-[0.15em] uppercase text-white/40 mb-2 block">Subject</Label>
              <Input
                id="subject"
                value={form.subject}
                onChange={(e) => setForm({ ...form, subject: e.target.value })}
                placeholder="Partnership · Media · General"
                className="bg-card border-white/10 text-white placeholder:text-white/20 focus-visible:ring-crimson/50 rounded-none h-11"
              />
            </div>
            <div>
              <Label htmlFor="message" className="text-xs font-600 tracking-[0.15em] uppercase text-white/40 mb-2 block">Message</Label>
              <Textarea
                id="message"
                required
                rows={6}
                value={form.message}
                onChange={(e) => setForm({ ...form, message: e.target.value })}
                placeholder="Your message..."
                className="bg-card border-white/10 text-white placeholder:text-white/20 focus-visible:ring-crimson/50 rounded-none resize-none"
              />
            </div>
            <button
              type="submit"
              disabled={sending}
              className="w-full flex items-center justify-center gap-3 bg-crimson text-white py-4 text-xs font-700 tracking-[0.15em] uppercase hover:bg-crimson/90 disabled:opacity-50 transition-colors group"
            >
              <Send className="w-3.5 h-3.5" />
              {sending ? "Transmitting..." : "Send Message"}
            </button>
          </form>
        )}
      </section>
    </div>
  );
}