import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';

import Layout from './components/layout/Layout';
import Home from './pages/Home';
import Team from './pages/Team';
import Campaign from './pages/Campaign';
import Results from './pages/Results';
import Media from './pages/Media';
import Partners from './pages/Partners';
import Sponsorship from './pages/Sponsorship';
import Contact from './pages/Contact';
import AdminDashboard from './pages/admin/AdminDashboard';
import SponsorTrackerPage from './pages/admin/SponsorTracker';
import BudgetTracker from './pages/admin/BudgetTracker';
import Messages from './pages/admin/Messages';
import TeamManager from './pages/admin/TeamManager';
import SailorProfile from './pages/SailorProfile';
import ResultsManager from './pages/admin/ResultsManager';
import PartnersManager from './pages/admin/PartnersManager';
import CampaignEditor from './pages/admin/CampaignEditor';
import HomeEditor from './pages/admin/HomeEditor';
import MediaManager from './pages/admin/MediaManager';
import News from './pages/News';
import NewsPostPage from './pages/NewsPost';
import NewsManager from './pages/admin/NewsManager';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      navigateToLogin();
      return null;
    }
  }

  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Home />} />
        <Route path="/team" element={<Team />} />
        <Route path="/campaign" element={<Campaign />} />
        <Route path="/results" element={<Results />} />
        <Route path="/media" element={<Media />} />
        <Route path="/partners" element={<Partners />} />
        <Route path="/sponsorship" element={<Sponsorship />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/admin" element={<AdminDashboard />} />
        <Route path="/admin/sponsors" element={<SponsorTrackerPage />} />
        <Route path="/admin/budget" element={<BudgetTracker />} />
        <Route path="/admin/messages" element={<Messages />} />
        <Route path="/admin/team" element={<TeamManager />} />
        <Route path="/admin/results" element={<ResultsManager />} />
        <Route path="/admin/partners" element={<PartnersManager />} />
        <Route path="/admin/campaign" element={<CampaignEditor />} />
        <Route path="/admin/home" element={<HomeEditor />} />
        <Route path="/admin/media" element={<MediaManager />} />
        <Route path="/admin/news" element={<NewsManager />} />
        <Route path="/news" element={<News />} />
        <Route path="/news/:id" element={<NewsPostPage />} />
        <Route path="/sailor/:id" element={<SailorProfile />} />
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};

function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App